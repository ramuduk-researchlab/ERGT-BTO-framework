"""
optimization/bto_optimizer.py
==============================
Bluefin Trevally Optimization (BTO) — bio-inspired metaheuristic
for automated hyperparameter search (Section 3.3.4, Section 4.6).

BTO is inspired by the cooperative foraging behaviour of Bluefin Trevally
fish. Key behavioural mechanisms:
  1. Global exploration: agents spread wide over the search space
     (analogous to Bluefin Trevally herding prey schools)
  2. Local exploitation: agents converge toward the best-known solution
     (analogous to coordinated attack on prey)
  3. Adaptive exploitation parameter α that decays over iterations,
     smoothly transitioning from exploration to exploitation

This adaptive decay is the key distinguishing feature vs PSO/GWO/WOA.
BTO converges in 42 epochs on ERGT, vs 57–88 for alternatives (Table 12).

Hyperparameter search space (used in the paper):
  - learning_rate     : [1e-5, 1e-2]  (log scale)
  - weight_decay      : [1e-6, 1e-3]  (log scale)
  - dropout           : [0.1, 0.5]
  - gcn_hidden_dim    : [64, 256]     (powers of 2)
  - transformer_heads : {4, 8}
  - transformer_layers: {2, 4, 6}
  - batch_size        : {16, 32}
  - delta_px          : [15, 80]      (graph edge threshold)
"""

from __future__ import annotations

import math
import random
from copy import deepcopy
from dataclasses import dataclass, field
from typing import Any, Callable, Dict, List, Optional, Tuple

import numpy as np


# ─────────────────────────────────────────────────────────────────────────────
# Search space definition
# ─────────────────────────────────────────────────────────────────────────────

@dataclass
class HyperparamSpace:
    """Define a continuous or discrete hyperparameter."""
    name: str
    low: float
    high: float
    log_scale: bool = False   # sample in log space
    choices: Optional[List[Any]] = None  # if set, sample from discrete choices

    def sample(self, rng: np.random.Generator) -> Any:
        if self.choices is not None:
            return rng.choice(self.choices)
        if self.log_scale:
            return float(np.exp(rng.uniform(np.log(self.low), np.log(self.high))))
        return float(rng.uniform(self.low, self.high))

    def clip(self, value: float) -> float:
        if self.choices is not None:
            # Return nearest choice
            return min(self.choices, key=lambda c: abs(c - value))
        val = np.clip(value, self.low, self.high)
        if self.log_scale:
            # Keep in log range
            val = np.clip(val, self.low, self.high)
        return float(val)


# Default ERGT-BTO search space (Section 3.3.4)
DEFAULT_SEARCH_SPACE: List[HyperparamSpace] = [
    HyperparamSpace("learning_rate",      1e-5, 1e-2, log_scale=True),
    HyperparamSpace("weight_decay",       1e-6, 1e-3, log_scale=True),
    HyperparamSpace("dropout",            0.1,  0.5),
    HyperparamSpace("gcn_hidden_dim",     64,   256,  choices=[64, 128, 192, 256]),
    HyperparamSpace("transformer_heads",  4,    8,    choices=[4, 8]),
    HyperparamSpace("transformer_layers", 2,    6,    choices=[2, 4, 6]),
    HyperparamSpace("batch_size",         16,   32,   choices=[16, 32]),
    HyperparamSpace("delta_px",           15.0, 80.0),
]


# ─────────────────────────────────────────────────────────────────────────────
# BTO agent (one fish in the school)
# ─────────────────────────────────────────────────────────────────────────────

@dataclass
class BTOAgent:
    params: Dict[str, Any]        # current hyperparameter values
    fitness: float = -float("inf")
    best_params: Dict[str, Any] = field(default_factory=dict)
    best_fitness: float = -float("inf")

    def __post_init__(self):
        self.best_params = deepcopy(self.params)


# ─────────────────────────────────────────────────────────────────────────────
# Bluefin Trevally Optimizer
# ─────────────────────────────────────────────────────────────────────────────

class BluefinTrevallyOptimizer:
    """
    BTO metaheuristic for deep learning hyperparameter optimization.

    Parameters
    ----------
    search_space     : List of HyperparamSpace objects defining bounds
    n_agents         : Population size (number of fish in school)
    max_iterations   : Maximum optimization iterations
    alpha_init       : Initial exploitation parameter α (high = more exploration)
    alpha_final      : Final α after decay (low = exploit best solution)
    alpha_decay      : Decay type; 'cosine' (default) | 'linear' | 'exponential'
    seed             : Random seed

    The key innovation is the cosine-annealed α that smoothly transitions
    from global search to refined local exploitation:

        α(t) = α_final + 0.5 * (α_init - α_final) * (1 + cos(π * t / T))
    """

    def __init__(
        self,
        search_space: List[HyperparamSpace] = None,
        n_agents: int = 20,
        max_iterations: int = 50,
        alpha_init: float = 2.0,
        alpha_final: float = 0.05,
        alpha_decay: str = "cosine",
        seed: int = 42,
    ):
        self.search_space = search_space or DEFAULT_SEARCH_SPACE
        self.n_agents = n_agents
        self.max_iterations = max_iterations
        self.alpha_init = alpha_init
        self.alpha_final = alpha_final
        self.alpha_decay = alpha_decay
        self.rng = np.random.default_rng(seed)

        # State
        self.agents: List[BTOAgent] = []
        self.global_best_params: Dict[str, Any] = {}
        self.global_best_fitness: float = -float("inf")
        self.history: List[Dict] = []

    # ── Initialization ────────────────────────────────────────────────────────

    def _init_agent(self) -> BTOAgent:
        params = {s.name: s.sample(self.rng) for s in self.search_space}
        return BTOAgent(params=params)

    def initialize(self) -> None:
        self.agents = [self._init_agent() for _ in range(self.n_agents)]
        self.global_best_params = {}
        self.global_best_fitness = -float("inf")

    # ── α schedule ───────────────────────────────────────────────────────────

    def _alpha(self, t: int) -> float:
        T = self.max_iterations
        if self.alpha_decay == "cosine":
            return self.alpha_final + 0.5 * (self.alpha_init - self.alpha_final) * (
                1 + math.cos(math.pi * t / T)
            )
        elif self.alpha_decay == "linear":
            return self.alpha_init + (self.alpha_final - self.alpha_init) * (t / T)
        elif self.alpha_decay == "exponential":
            rate = math.log(self.alpha_final / self.alpha_init) / T
            return self.alpha_init * math.exp(rate * t)
        return self.alpha_final

    # ── Position update ───────────────────────────────────────────────────────

    def _update_agent(self, agent: BTOAgent, t: int) -> BTOAgent:
        """
        BTO position update rule:

            x_new = x + α * r1 * (x_best_global - x)
                      + (1-α) * r2 * (x_best_personal - x)
                      + noise_term

        where r1, r2 ~ U(0,1) and noise_term provides exploration diversity.
        """
        alpha = self._alpha(t)
        new_params = {}

        for space in self.search_space:
            name = space.name
            x     = agent.params[name]
            x_g   = self.global_best_params.get(name, x)
            x_p   = agent.best_params.get(name, x)

            r1 = float(self.rng.uniform())
            r2 = float(self.rng.uniform())

            # Herding step: move toward global best (exploration)
            herd = alpha * r1 * (x_g - x)
            # Attack step: converge to personal best (exploitation)
            attack = (1 - alpha) * r2 * (x_p - x)
            # Lévy-like noise for diversity
            noise_scale = alpha * 0.1 * (space.high - space.low)
            noise = float(self.rng.normal(0, noise_scale))

            x_new = x + herd + attack + noise

            if space.choices is not None:
                x_new = space.clip(x_new)
            elif space.log_scale:
                # Update in log space
                log_x     = math.log(max(x, space.low))
                log_xg    = math.log(max(x_g, space.low))
                log_xp    = math.log(max(x_p, space.low))
                log_new = log_x + (alpha * r1 * (log_xg - log_x)
                                   + (1 - alpha) * r2 * (log_xp - log_x)
                                   + noise * 0.1)
                x_new = math.exp(np.clip(log_new, math.log(space.low), math.log(space.high)))
            else:
                x_new = space.clip(x_new)

            new_params[name] = x_new

        return BTOAgent(params=new_params)

    # ── Main optimization loop ────────────────────────────────────────────────

    def optimize(
        self,
        fitness_fn: Callable[[Dict[str, Any]], float],
        verbose: bool = True,
    ) -> Dict[str, Any]:
        """
        Run BTO optimization.

        Args:
            fitness_fn: Function that takes a hyperparameter dict and returns
                        a scalar fitness score (higher = better; e.g. val accuracy).
            verbose   : Print iteration progress.

        Returns:
            best_params: Hyperparameter dict achieving highest fitness.
        """
        self.initialize()

        # Evaluate initial population
        for agent in self.agents:
            agent.fitness = fitness_fn(agent.params)
            agent.best_fitness = agent.fitness
            agent.best_params  = deepcopy(agent.params)
            if agent.fitness > self.global_best_fitness:
                self.global_best_fitness = agent.fitness
                self.global_best_params  = deepcopy(agent.params)

        if verbose:
            print(f"[BTO] Init | best_fitness={self.global_best_fitness:.4f}")

        for t in range(1, self.max_iterations + 1):
            alpha = self._alpha(t)
            new_agents = []

            for agent in self.agents:
                new_agent = self._update_agent(agent, t)
                new_agent.fitness = fitness_fn(new_agent.params)

                # Update personal best
                if new_agent.fitness > agent.best_fitness:
                    new_agent.best_fitness = new_agent.fitness
                    new_agent.best_params  = deepcopy(new_agent.params)
                else:
                    new_agent.best_fitness = agent.best_fitness
                    new_agent.best_params  = deepcopy(agent.best_params)

                # Update global best
                if new_agent.fitness > self.global_best_fitness:
                    self.global_best_fitness = new_agent.fitness
                    self.global_best_params  = deepcopy(new_agent.params)

                new_agents.append(new_agent)

            self.agents = new_agents
            self.history.append({
                "iteration": t,
                "alpha": alpha,
                "best_fitness": self.global_best_fitness,
                "best_params": deepcopy(self.global_best_params),
            })

            if verbose:
                print(
                    f"[BTO] Iter {t:3d}/{self.max_iterations} | "
                    f"α={alpha:.3f} | best={self.global_best_fitness:.4f}"
                )

        return self.global_best_params

    def print_convergence_summary(self) -> None:
        """Print convergence statistics after optimization."""
        if not self.history:
            print("No history available. Run optimize() first.")
            return
        fitnesses = [h["best_fitness"] for h in self.history]
        print("\n─── BTO Convergence Summary ───────────────────────────────")
        print(f"  Iterations       : {len(self.history)}")
        print(f"  Initial fitness  : {fitnesses[0]:.4f}")
        print(f"  Final fitness    : {fitnesses[-1]:.4f}")
        print(f"  Improvement      : {fitnesses[-1] - fitnesses[0]:+.4f}")
        print(f"\n  Best Hyperparameters:")
        for k, v in self.global_best_params.items():
            if isinstance(v, float):
                print(f"    {k:<25} = {v:.6g}")
            else:
                print(f"    {k:<25} = {v}")
        print("─" * 55)
