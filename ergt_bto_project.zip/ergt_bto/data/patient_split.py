"""
data/patient_split.py
=====================
Patient-level stratified train / val / test splitting (Section 3.1.3).

Key rules from the paper:
  - 70% patients → train, 15% → val, 15% → test
  - Split occurs BEFORE any augmentation
  - Each image is assigned a patient_id; all images from a patient go to
    the same partition (no data leakage across splits)
  - Class proportions are preserved in every split (stratified)
"""

from __future__ import annotations

from collections import defaultdict
from typing import Dict, List, Optional, Tuple

import numpy as np
from sklearn.model_selection import StratifiedShuffleSplit


def build_patient_splits(
    patient_ids: List[str],
    labels: List[int],
    train_frac: float = 0.70,
    val_frac: float = 0.15,
    seed: int = 42,
) -> Tuple[List[int], List[int], List[int]]:
    """
    Create patient-level stratified splits and return sample-level indices.

    Parameters
    ----------
    patient_ids : per-sample patient identifier strings
    labels      : per-sample integer class labels
    train_frac  : fraction of *patients* in the training split
    val_frac    : fraction of *patients* in the validation split
                  (test_frac = 1 - train_frac - val_frac)
    seed        : random seed for reproducibility

    Returns
    -------
    train_idx, val_idx, test_idx : lists of sample-level integer indices
    """
    assert len(patient_ids) == len(labels), "patient_ids and labels must be same length"
    assert 0 < train_frac < 1 and 0 < val_frac < 1
    assert train_frac + val_frac < 1.0

    # ── 1. Aggregate patients ────────────────────────────────────────────────
    patient_to_indices: Dict[str, List[int]] = defaultdict(list)
    patient_to_label: Dict[str, int] = {}

    for i, (pid, lbl) in enumerate(zip(patient_ids, labels)):
        patient_to_indices[pid].append(i)
        # Use the majority label for this patient (handles multi-image patients)
        if pid not in patient_to_label:
            patient_to_label[pid] = lbl

    unique_patients = np.array(sorted(patient_to_indices.keys()))
    patient_labels  = np.array([patient_to_label[p] for p in unique_patients])

    n_patients = len(unique_patients)

    # ── 2. First split: (train) vs (val + test) ──────────────────────────────
    val_test_frac = 1.0 - train_frac
    sss1 = StratifiedShuffleSplit(
        n_splits=1, test_size=val_test_frac, random_state=seed
    )
    train_pat_idx, val_test_pat_idx = next(sss1.split(unique_patients, patient_labels))

    val_test_patients = unique_patients[val_test_pat_idx]
    val_test_labels   = patient_labels[val_test_pat_idx]

    # ── 3. Second split: val vs test (equal halves of the remaining) ─────────
    val_size_within = val_frac / val_test_frac   # relative size of val within val+test
    sss2 = StratifiedShuffleSplit(
        n_splits=1, test_size=1.0 - val_size_within, random_state=seed
    )
    val_pat_local_idx, test_pat_local_idx = next(
        sss2.split(val_test_patients, val_test_labels)
    )

    train_patients = unique_patients[train_pat_idx]
    val_patients   = val_test_patients[val_pat_local_idx]
    test_patients  = val_test_patients[test_pat_local_idx]

    # ── 4. Expand patients → sample indices ──────────────────────────────────
    def patients_to_sample_indices(patient_list: np.ndarray) -> List[int]:
        idx: List[int] = []
        for pid in patient_list:
            idx.extend(patient_to_indices[pid])
        return sorted(idx)

    train_idx = patients_to_sample_indices(train_patients)
    val_idx   = patients_to_sample_indices(val_patients)
    test_idx  = patients_to_sample_indices(test_patients)

    # ── 5. Sanity checks ─────────────────────────────────────────────────────
    assert len(set(train_idx) & set(val_idx)) == 0,  "Train/Val overlap!"
    assert len(set(train_idx) & set(test_idx)) == 0, "Train/Test overlap!"
    assert len(set(val_idx)   & set(test_idx)) == 0, "Val/Test overlap!"
    assert len(train_idx) + len(val_idx) + len(test_idx) == len(patient_ids)

    print(
        f"[PatientSplit] {n_patients} patients → "
        f"train={len(train_patients)} pts ({len(train_idx)} imgs) | "
        f"val={len(val_patients)} pts ({len(val_idx)} imgs) | "
        f"test={len(test_patients)} pts ({len(test_idx)} imgs)"
    )

    return train_idx, val_idx, test_idx


def print_split_class_distribution(
    labels: List[int],
    train_idx: List[int],
    val_idx: List[int],
    test_idx: List[int],
    class_names: Optional[List[str]] = None,
) -> None:
    """Print per-class sample counts for each split."""
    from collections import Counter

    if class_names is None:
        class_names = [str(i) for i in sorted(set(labels))]

    labels_arr = np.array(labels)
    header = f"{'Class':<20} {'Train':>8} {'Val':>8} {'Test':>8}"
    print("\n" + header)
    print("-" * len(header))

    for cls_idx, name in enumerate(class_names):
        n_train = np.sum(labels_arr[train_idx] == cls_idx)
        n_val   = np.sum(labels_arr[val_idx]   == cls_idx)
        n_test  = np.sum(labels_arr[test_idx]  == cls_idx)
        print(f"{name:<20} {n_train:>8} {n_val:>8} {n_test:>8}")

    print("-" * len(header))
    print(f"{'Total':<20} {len(train_idx):>8} {len(val_idx):>8} {len(test_idx):>8}\n")
