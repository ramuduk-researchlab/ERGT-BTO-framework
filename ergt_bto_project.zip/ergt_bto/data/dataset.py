"""
data/dataset.py
===============
Dataset loaders for BACH and BreaKHis histopathology datasets.

BACH:
  - 400 H&E images at 200× (2048×1536 px)
  - 4 classes: Normal(0), Benign(1), In-Situ(2), Invasive(3)
  - https://iciar2018-challenge.grand-challenge.org/Dataset/

BreaKHis:
  - 7,909 images from 82 patients, 4 magnifications (40×/100×/200×/400×)
  - Binary (benign/malignant) → mapped to 4-class BACH taxonomy for
    cross-dataset generalization experiments
  - https://web.inf.ufpr.br/vri/databases/breast-cancer-histopathological-database-breakhis/
"""

import os
import re
from pathlib import Path
from typing import List, Tuple, Optional, Dict

import numpy as np
from PIL import Image
import torch
from torch.utils.data import Dataset
from torchvision import transforms


# ─────────────────────────────────────────────────────────────────────────────
# Class maps
# ─────────────────────────────────────────────────────────────────────────────

BACH_CLASSES: Dict[str, int] = {
    "normal":   0,
    "benign":   1,
    "insitu":   2,
    "invasive": 3,
}

# BreaKHis subtype → 4-class BACH label mapping (Section 3.1.2)
BREAKHIS_TO_BACH: Dict[str, int] = {
    # benign subtypes  → Benign
    "adenosis":          1,
    "fibroadenoma":      1,
    "phyllodes_tumor":   1,
    "tubular_adenoma":   1,
    # DCIS             → In-Situ
    "ductal_carcinoma":  2,   # in-situ variant (mapped conservatively)
    # invasive carcinomas → Invasive
    "lobular_carcinoma": 3,
    "mucinous_carcinoma":3,
    "papillary_carcinoma":3,
    # normal patches extracted by pathologists → Normal
    "normal":            0,
}

LABEL_NAMES = ["Normal", "Benign", "In-Situ", "Invasive"]


# ─────────────────────────────────────────────────────────────────────────────
# Base transforms (applied after preprocessing; see preprocessing.py)
# ─────────────────────────────────────────────────────────────────────────────

def get_base_transform(image_size: int = 224) -> transforms.Compose:
    """Resize + ToTensor only (normalization done in preprocessing.py)."""
    return transforms.Compose([
        transforms.Resize((image_size, image_size), interpolation=Image.BICUBIC),
        transforms.ToTensor(),   # [0,1]
    ])


def get_train_augmentation(image_size: int = 224) -> transforms.Compose:
    """
    Training-only augmentations (Section 3.2.4):
      - Random rotation [0°, 360°]
      - Random horizontal/vertical flip (p=0.5)
      - Random zoom [0.8×, 1.2×]
      - Brightness/contrast jitter [0.85, 1.15]
      - Gaussian noise is applied separately (see preprocessing.py)
    """
    return transforms.Compose([
        transforms.Resize((int(image_size * 1.15), int(image_size * 1.15)),
                          interpolation=Image.BICUBIC),
        transforms.RandomRotation(degrees=360),
        transforms.RandomHorizontalFlip(p=0.5),
        transforms.RandomVerticalFlip(p=0.5),
        transforms.RandomResizedCrop(
            image_size,
            scale=(0.8, 1.2),
            ratio=(0.9, 1.1),
            interpolation=Image.BICUBIC,
        ),
        transforms.ColorJitter(brightness=0.15, contrast=0.15),
        transforms.ToTensor(),
    ])


# ─────────────────────────────────────────────────────────────────────────────
# BACH Dataset
# ─────────────────────────────────────────────────────────────────────────────

class BACHDataset(Dataset):
    """
    BACH Breast Cancer Histology Dataset.

    Expected directory layout:
        root/
          Normal/     *.tif  (100 images)
          Benign/     *.tif  (100 images)
          InSitu/     *.tif  (100 images)
          Invasive/   *.tif  (100 images)

    Args:
        root        : Path to the BACH root directory.
        split_indices: List of integer indices belonging to this split.
        transform   : torchvision transform applied to each PIL image.
        image_size  : Target spatial size (default 224).
    """

    CLASS_DIRS = {
        "Normal":   0,
        "Benign":   1,
        "InSitu":   2,
        "Invasive": 3,
    }

    def __init__(
        self,
        root: str,
        split_indices: Optional[List[int]] = None,
        transform: Optional[transforms.Compose] = None,
        image_size: int = 224,
    ) -> None:
        self.root = Path(root)
        self.transform = transform or get_base_transform(image_size)
        self.image_size = image_size

        # Collect all (path, label, patient_id) tuples
        self.samples: List[Tuple[Path, int, str]] = []
        for class_dir, label in self.CLASS_DIRS.items():
            class_path = self.root / class_dir
            if not class_path.exists():
                raise FileNotFoundError(
                    f"BACH class directory not found: {class_path}\n"
                    "Download from https://iciar2018-challenge.grand-challenge.org/Dataset/"
                )
            for img_path in sorted(class_path.glob("*.tif")):
                # BACH patient id derived from filename (e.g. "b001.tif" → "b001")
                patient_id = f"{class_dir}_{img_path.stem}"
                self.samples.append((img_path, label, patient_id))

        # Apply split indices if provided
        if split_indices is not None:
            self.samples = [self.samples[i] for i in split_indices]

    def __len__(self) -> int:
        return len(self.samples)

    def __getitem__(self, idx: int) -> Tuple[torch.Tensor, int, str]:
        img_path, label, patient_id = self.samples[idx]
        image = Image.open(img_path).convert("RGB")
        if self.transform:
            image = self.transform(image)
        return image, label, patient_id

    def get_patient_ids(self) -> List[str]:
        return [s[2] for s in self.samples]

    def get_labels(self) -> List[int]:
        return [s[1] for s in self.samples]


# ─────────────────────────────────────────────────────────────────────────────
# BreaKHis Dataset
# ─────────────────────────────────────────────────────────────────────────────

class BreaKHisDataset(Dataset):
    """
    BreaKHis Breast Cancer Histopathological Image Dataset.

    Expected directory layout (standard BreaKHis structure):
        root/
          breast_cancer_organized/
            benign/
              SOB/
                adenosis/
                  SOB_B_A_14-22549AB/
                    40X/  *.png
                    100X/ *.png
                    200X/ *.png
                    400X/ *.png
                fibroadenoma/ ...
                phyllodes_tumor/ ...
                tubular_adenoma/ ...
            malignant/
              SOB/
                ductal_carcinoma/ ...
                lobular_carcinoma/ ...
                mucinous_carcinoma/ ...
                papillary_carcinoma/ ...

    Args:
        root         : Path to BreaKHis root.
        magnification: One of [40, 100, 200, 400] or None (use all).
        map_to_bach  : If True, maps subtypes to the 4-class BACH taxonomy.
        split_indices: Subset of sample indices.
        transform    : torchvision transform.
        image_size   : Target spatial size.
    """

    def __init__(
        self,
        root: str,
        magnification: Optional[int] = None,
        map_to_bach: bool = True,
        split_indices: Optional[List[int]] = None,
        transform: Optional[transforms.Compose] = None,
        image_size: int = 224,
    ) -> None:
        self.root = Path(root)
        self.magnification = magnification
        self.map_to_bach = map_to_bach
        self.transform = transform or get_base_transform(image_size)
        self.image_size = image_size

        self.samples: List[Tuple[Path, int, str]] = []
        self._scan_directory()

        if split_indices is not None:
            self.samples = [self.samples[i] for i in split_indices]

    def _scan_directory(self) -> None:
        mag_pattern = (
            f"{self.magnification}X" if self.magnification else "*X"
        )
        for img_path in sorted(self.root.rglob("*.png")):
            parts = img_path.parts
            # Extract subtype from directory hierarchy
            subtype = self._extract_subtype(img_path)
            if subtype is None:
                continue
            # Filter by magnification
            if self.magnification and mag_pattern not in str(img_path):
                continue
            # Determine label
            if self.map_to_bach:
                label = BREAKHIS_TO_BACH.get(subtype, -1)
            else:
                label = 0 if "benign" in str(img_path).lower() else 1
            if label == -1:
                continue
            # Patient ID from filename (e.g. SOB_B_A_14-22549AB_40X_001.png)
            patient_id = self._extract_patient_id(img_path)
            self.samples.append((img_path, label, patient_id))

    @staticmethod
    def _extract_subtype(img_path: Path) -> Optional[str]:
        """Extract subtype name from path components."""
        subtype_map = {
            "adenosis": "adenosis",
            "fibroadenoma": "fibroadenoma",
            "phyllodes_tumor": "phyllodes_tumor",
            "tubular_adenoma": "tubular_adenoma",
            "ductal_carcinoma": "ductal_carcinoma",
            "lobular_carcinoma": "lobular_carcinoma",
            "mucinous_carcinoma": "mucinous_carcinoma",
            "papillary_carcinoma": "papillary_carcinoma",
        }
        path_str = str(img_path).lower()
        for key in subtype_map:
            if key in path_str:
                return subtype_map[key]
        return None

    @staticmethod
    def _extract_patient_id(img_path: Path) -> str:
        """
        BreaKHis filenames encode patient info in the SOB_*_PATIENT pattern.
        Extract the patient-level identifier for data splitting.
        """
        match = re.search(r"SOB_[A-Z]_[A-Z]+_\d+-\w+", img_path.stem, re.IGNORECASE)
        if match:
            return match.group(0)
        # Fallback: use parent directory name as patient proxy
        return img_path.parent.parent.name

    def __len__(self) -> int:
        return len(self.samples)

    def __getitem__(self, idx: int) -> Tuple[torch.Tensor, int, str]:
        img_path, label, patient_id = self.samples[idx]
        image = Image.open(img_path).convert("RGB")
        if self.transform:
            image = self.transform(image)
        return image, label, patient_id

    def get_patient_ids(self) -> List[str]:
        return [s[2] for s in self.samples]

    def get_labels(self) -> List[int]:
        return [s[1] for s in self.samples]


# ─────────────────────────────────────────────────────────────────────────────
# Factory
# ─────────────────────────────────────────────────────────────────────────────

def build_dataset(
    name: str,
    root: str,
    split: str = "train",
    split_indices: Optional[List[int]] = None,
    image_size: int = 224,
    magnification: Optional[int] = None,
    map_to_bach: bool = True,
) -> Dataset:
    """
    Factory function for dataset construction.

    Args:
        name         : 'bach' or 'breakhis'
        root         : Path to dataset root
        split        : 'train', 'val', or 'test'
        split_indices: Pre-computed patient-level indices
        image_size   : Resize target (default 224)
        magnification: For BreaKHis; None = use all magnifications
        map_to_bach  : For BreaKHis; map to 4-class BACH taxonomy

    Returns:
        torch.utils.data.Dataset instance
    """
    is_train = (split == "train")
    transform = get_train_augmentation(image_size) if is_train else get_base_transform(image_size)

    if name.lower() == "bach":
        return BACHDataset(root, split_indices=split_indices, transform=transform, image_size=image_size)
    elif name.lower() == "breakhis":
        return BreaKHisDataset(
            root,
            magnification=magnification,
            map_to_bach=map_to_bach,
            split_indices=split_indices,
            transform=transform,
            image_size=image_size,
        )
    else:
        raise ValueError(f"Unknown dataset: {name}. Choose 'bach' or 'breakhis'.")
