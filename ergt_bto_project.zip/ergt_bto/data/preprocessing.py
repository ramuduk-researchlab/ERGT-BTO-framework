"""
data/preprocessing.py
======================
Histopathology preprocessing pipeline (Section 3.2):
  1. Image resizing to 224×224 via bicubic interpolation
  2. Macenko stain normalization (Section 3.2.2)
  3. Per-channel z-score intensity normalization (Section 3.2.3)
  4. Training-only data augmentation including stain-space perturbations (Section 3.2.4)
"""

from __future__ import annotations

import numpy as np
from PIL import Image
from typing import Optional, Tuple

import torch
from torchvision import transforms


# ─────────────────────────────────────────────────────────────────────────────
# Macenko Stain Normalizer
# ─────────────────────────────────────────────────────────────────────────────

class MacenkoStainNormalizer:
    """
    Macenko stain normalization in optical density (OD) space via SVD.

    Reference:
        Macenko, M. et al. (2009). A method for normalizing histology
        slides for quantitative analysis. ISBI 2009.

    Usage:
        normalizer = MacenkoStainNormalizer()
        normalizer.fit(reference_image_rgb_numpy)   # H×W×3 uint8
        normalized = normalizer.transform(target_image_rgb_numpy)
    """

    def __init__(self, luminosity_threshold: float = 0.8, angular_percentile: float = 99.0):
        self.luminosity_threshold = luminosity_threshold
        self.angular_percentile = angular_percentile
        self.stain_matrix_target: Optional[np.ndarray] = None
        self.max_concentrations_target: Optional[np.ndarray] = None

    @staticmethod
    def _rgb_to_od(img: np.ndarray) -> np.ndarray:
        """Convert RGB image [0,255] to optical density."""
        img = img.astype(np.float64)
        img = np.clip(img, 1, 255)
        return -np.log(img / 255.0)

    @staticmethod
    def _od_to_rgb(od: np.ndarray) -> np.ndarray:
        """Convert optical density back to RGB [0,255]."""
        return (np.exp(-od) * 255).clip(0, 255).astype(np.uint8)

    def _get_stain_matrix(self, img_rgb: np.ndarray) -> Tuple[np.ndarray, np.ndarray]:
        """Extract H&E stain vectors and concentrations using SVD."""
        od = self._rgb_to_od(img_rgb.reshape(-1, 3))

        # Remove background (near-white pixels)
        od_norm = np.sqrt((od ** 2).sum(axis=1, keepdims=True))
        mask = od_norm.flatten() > self.luminosity_threshold
        od_hat = od[mask]
        if len(od_hat) < 10:
            od_hat = od  # fallback: use all pixels

        # SVD to find stain directions
        _, _, V = np.linalg.svd(od_hat, full_matrices=False)
        V = V[:2].T   # 3×2: two principal stain directions

        # Project OD values onto plane spanned by V
        proj = od_hat @ V  # N×2

        # Robust angular extremes
        angles = np.arctan2(proj[:, 1], proj[:, 0])
        phi1 = np.percentile(angles, 100 - self.angular_percentile)
        phi2 = np.percentile(angles, self.angular_percentile)

        v1 = np.array([np.cos(phi1), np.sin(phi1)])
        v2 = np.array([np.cos(phi2), np.sin(phi2)])

        stain_matrix = np.array([V @ v1, V @ v2])  # 2×3 (H, E)
        # Normalise stain vectors
        stain_matrix /= np.linalg.norm(stain_matrix, axis=1, keepdims=True) + 1e-8
        return stain_matrix  # 2×3

    def _get_concentrations(self, img_rgb: np.ndarray, stain_matrix: np.ndarray) -> np.ndarray:
        """Compute H&E concentrations via non-negative least squares."""
        od = self._rgb_to_od(img_rgb.reshape(-1, 3))
        # Solve: stain_matrix.T @ conc = od.T  →  conc = lstsq
        conc, _, _, _ = np.linalg.lstsq(stain_matrix.T, od.T, rcond=None)
        return conc.T  # N×2

    def fit(self, reference_img: np.ndarray) -> "MacenkoStainNormalizer":
        """Fit normalizer on a reference H&E image (H×W×3, uint8)."""
        self.stain_matrix_target = self._get_stain_matrix(reference_img)
        conc = self._get_concentrations(reference_img, self.stain_matrix_target)
        self.max_concentrations_target = np.percentile(conc, 99, axis=0)
        return self

    def transform(self, img_rgb: np.ndarray) -> np.ndarray:
        """Normalize a source image to the target stain space."""
        if self.stain_matrix_target is None:
            raise RuntimeError("Call fit() before transform().")

        h, w = img_rgb.shape[:2]
        stain_matrix_source = self._get_stain_matrix(img_rgb)
        conc_source = self._get_concentrations(img_rgb, stain_matrix_source)
        max_conc_source = np.percentile(conc_source, 99, axis=0)

        # Normalise concentrations and reconstruct with target stain matrix
        conc_norm = conc_source / (max_conc_source + 1e-8) * self.max_concentrations_target
        od_norm = conc_norm @ self.stain_matrix_target
        img_norm = self._od_to_rgb(od_norm).reshape(h, w, 3)
        return img_norm


# ─────────────────────────────────────────────────────────────────────────────
# Stain-space augmentation
# ─────────────────────────────────────────────────────────────────────────────

class StainAugmentation:
    """
    Randomly perturb the Macenko stain matrix parameters to simulate
    inter-scanner and inter-laboratory staining variability (Section 3.2.4).
    """

    def __init__(self, sigma: float = 0.05, p: float = 0.5):
        self.sigma = sigma
        self.p = p
        self._normalizer = MacenkoStainNormalizer()

    def __call__(self, img: np.ndarray) -> np.ndarray:
        if np.random.rand() > self.p:
            return img
        try:
            stain_matrix = self._normalizer._get_stain_matrix(img)
            conc = self._normalizer._get_concentrations(img, stain_matrix)

            # Perturb concentrations
            noise = np.random.normal(1.0, self.sigma, conc.shape)
            conc_aug = conc * noise

            od_aug = conc_aug @ stain_matrix
            return MacenkoStainNormalizer._od_to_rgb(od_aug).reshape(img.shape)
        except Exception:
            return img  # fallback to unchanged image on numerical failure


# ─────────────────────────────────────────────────────────────────────────────
# Gaussian noise injection
# ─────────────────────────────────────────────────────────────────────────────

class AddGaussianNoise:
    """Add per-pixel Gaussian noise with σ ∈ [sigma_min, sigma_max]."""

    def __init__(self, sigma_min: float = 0.01, sigma_max: float = 0.05):
        self.sigma_min = sigma_min
        self.sigma_max = sigma_max

    def __call__(self, tensor: torch.Tensor) -> torch.Tensor:
        sigma = np.random.uniform(self.sigma_min, self.sigma_max)
        noise = torch.randn_like(tensor) * sigma
        return (tensor + noise).clamp(0.0, 1.0)


# ─────────────────────────────────────────────────────────────────────────────
# Per-channel z-score normalization (Section 3.2.3, Eq. 1)
# ─────────────────────────────────────────────────────────────────────────────

class ZScoreNormalize:
    """
    Per-channel z-score normalization:  x̂ = (x − μ) / σ

    Operates on a torch.Tensor of shape (C, H, W) in [0, 1].
    """

    def __call__(self, tensor: torch.Tensor) -> torch.Tensor:
        mean = tensor.mean(dim=(1, 2), keepdim=True)   # (C,1,1)
        std  = tensor.std(dim=(1, 2), keepdim=True) + 1e-8
        return (tensor - mean) / std


# ─────────────────────────────────────────────────────────────────────────────
# Complete preprocessing pipeline builder
# ─────────────────────────────────────────────────────────────────────────────

def build_preprocessing_pipeline(
    reference_image: Optional[np.ndarray] = None,
    image_size: int = 224,
    is_train: bool = False,
    stain_augment: bool = True,
    stain_augment_sigma: float = 0.05,
) -> transforms.Compose:
    """
    Build the full preprocessing transform pipeline.

    For inference/val/test: resize → (stain_norm) → ToTensor → z-score
    For training:           resize → (stain_norm) → geometric aug → ToTensor → noise → z-score

    Args:
        reference_image  : Optional reference image (H×W×3 uint8) for Macenko fitting.
                           If None, stain normalization is skipped.
        image_size       : Target size (default 224).
        is_train         : Apply training augmentation if True.
        stain_augment    : Apply stain-space augmentation during training.
        stain_augment_sigma: Perturbation sigma for stain augmentation.

    Returns:
        torchvision.transforms.Compose
    """

    pipeline = []

    # 1. Stain normalization (PIL→numpy→PIL)
    if reference_image is not None:
        normalizer = MacenkoStainNormalizer()
        normalizer.fit(reference_image)

        class _StainNormTransform:
            def __init__(self, norm):
                self._norm = norm
            def __call__(self, img: Image.Image) -> Image.Image:
                arr = np.array(img)
                arr_norm = self._norm.transform(arr)
                return Image.fromarray(arr_norm)

        pipeline.append(_StainNormTransform(normalizer))

    # 2. Resize
    pipeline.append(transforms.Resize((image_size, image_size), interpolation=Image.BICUBIC))

    if is_train:
        # 3. Geometric augmentation
        pipeline += [
            transforms.RandomRotation(degrees=360),
            transforms.RandomHorizontalFlip(p=0.5),
            transforms.RandomVerticalFlip(p=0.5),
            transforms.RandomResizedCrop(image_size, scale=(0.8, 1.2), ratio=(0.9, 1.1)),
            transforms.ColorJitter(brightness=0.15, contrast=0.15),
        ]

        # 4. Stain-space augmentation (numpy)
        if stain_augment:
            stain_aug = StainAugmentation(sigma=stain_augment_sigma)

            class _StainAugTransform:
                def __init__(self, aug):
                    self._aug = aug
                def __call__(self, img: Image.Image) -> Image.Image:
                    arr = self._aug(np.array(img))
                    return Image.fromarray(arr.astype(np.uint8))

            pipeline.append(_StainAugTransform(stain_aug))

    # 5. To tensor [0, 1]
    pipeline.append(transforms.ToTensor())

    if is_train:
        # 6. Gaussian noise
        pipeline.append(AddGaussianNoise(sigma_min=0.01, sigma_max=0.05))

    # 7. Z-score normalization
    pipeline.append(ZScoreNormalize())

    return transforms.Compose(pipeline)
