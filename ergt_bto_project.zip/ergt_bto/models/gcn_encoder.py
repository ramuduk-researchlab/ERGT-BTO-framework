"""
models/gcn_encoder.py
=====================
Cell Graph Construction and GCN Encoding (Section 3.3, Section 4.5).

Steps:
  1. Nucleus detection via a simple threshold-based segmentation proxy
     (or externally supplied coordinates from HoVer-Net).
  2. k-NN / radius graph construction with edge distance threshold δ.
     BTO optimal δ = 42 px on BACH (Table 11).
  3. Two-layer GCN (Kipf & Welling 2017) with mean-pooling readout.

Graph message passing (Eq. from Section 3.3):
  H^(l+1) = ReLU(D^{-1/2} Â D^{-1/2} H^(l) W^(l))
  where Â = A + I (self-loops added)
"""

from __future__ import annotations

from typing import List, Optional, Tuple

import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
from scipy.ndimage import label as scipy_label


# ─────────────────────────────────────────────────────────────────────────────
# Nucleus detection (lightweight proxy)
# ─────────────────────────────────────────────────────────────────────────────

def detect_nuclei_simple(
    img_rgb: np.ndarray,
    min_area: int = 50,
    max_area: int = 2000,
) -> np.ndarray:
    """
    Simple nucleus detector using Otsu thresholding on the haematoxylin channel.
    Returns centroids as (N, 2) array of (row, col) coordinates.

    For production, replace with HoVer-Net outputs (Section 3.3 reference [27]).
    """
    # Extract approximate haematoxylin channel (dark blue/purple pixels)
    img_f = img_rgb.astype(np.float32) / 255.0
    # Optical density approximation
    od = -np.log(img_f + 1e-6)
    # Haematoxylin ≈ first principal component of OD (simplified: use od-sum)
    haem = od.sum(axis=2)  # H×W

    # Normalize and threshold
    haem_norm = (haem - haem.min()) / (haem.max() - haem.min() + 1e-8)
    from skimage.filters import threshold_otsu
    thresh = threshold_otsu(haem_norm)
    binary = haem_norm > thresh

    # Label connected components
    labeled, n_labels = scipy_label(binary)
    centroids = []
    for i in range(1, n_labels + 1):
        coords = np.argwhere(labeled == i)
        area = len(coords)
        if min_area <= area <= max_area:
            centroid = coords.mean(axis=0)  # (row, col)
            centroids.append(centroid)

    if len(centroids) == 0:
        # Fallback: uniform grid of virtual nodes
        H, W = img_rgb.shape[:2]
        grid_step = 16
        centroids = [
            [r, c]
            for r in range(grid_step // 2, H, grid_step)
            for c in range(grid_step // 2, W, grid_step)
        ]

    return np.array(centroids, dtype=np.float32)  # (N, 2)


# ─────────────────────────────────────────────────────────────────────────────
# Graph construction utilities
# ─────────────────────────────────────────────────────────────────────────────

def build_radius_graph(
    node_positions: np.ndarray,
    delta: float = 42.0,
    max_edges_per_node: int = 20,
) -> Tuple[torch.Tensor, torch.Tensor]:
    """
    Build an undirected radius graph: connect nodes within Euclidean distance δ.

    BTO optimal δ = 42 px for BACH dataset (Table 11).

    Args:
        node_positions: (N, 2) centroid coordinates
        delta         : Maximum edge distance threshold (pixels)
        max_edges_per_node: Cap per-node degree to avoid over-connectivity

    Returns:
        edge_index: (2, E) LongTensor of edge indices
        edge_attr : (E,)  FloatTensor of normalized edge distances
    """
    N = len(node_positions)
    if N == 0:
        return torch.zeros((2, 0), dtype=torch.long), torch.zeros(0)

    # Pairwise distances
    pos = torch.tensor(node_positions, dtype=torch.float32)
    diff = pos.unsqueeze(0) - pos.unsqueeze(1)   # (N, N, 2)
    dist = diff.norm(dim=-1)                      # (N, N)

    # Mask: within delta, not self-loop
    mask = (dist <= delta) & (dist > 0)

    src_list, dst_list, attr_list = [], [], []
    for i in range(N):
        neighbors = mask[i].nonzero(as_tuple=True)[0]
        dists_i   = dist[i][neighbors]
        if len(neighbors) > max_edges_per_node:
            topk = dists_i.topk(max_edges_per_node, largest=False).indices
            neighbors = neighbors[topk]
            dists_i   = dists_i[topk]
        src_list.extend([i] * len(neighbors))
        dst_list.extend(neighbors.tolist())
        attr_list.extend((dists_i / (delta + 1e-8)).tolist())

    if not src_list:
        # Fully disconnected: add self-loops as fallback
        src_list = list(range(N))
        dst_list = list(range(N))
        attr_list = [0.0] * N

    edge_index = torch.tensor([src_list, dst_list], dtype=torch.long)
    edge_attr  = torch.tensor(attr_list, dtype=torch.float32)
    return edge_index, edge_attr


# ─────────────────────────────────────────────────────────────────────────────
# GCN layer (Kipf & Welling 2017)
# ─────────────────────────────────────────────────────────────────────────────

class GCNLayer(nn.Module):
    """
    Single GCN layer:  H' = ReLU(D̂^{-1/2} Â D̂^{-1/2} H W)

    Implemented without PyG dependency for portability;
    uses sparse matrix multiply via torch.sparse.
    """

    def __init__(self, in_dim: int, out_dim: int, bias: bool = True):
        super().__init__()
        self.W = nn.Linear(in_dim, out_dim, bias=bias)
        self.norm = nn.LayerNorm(out_dim)

    def forward(
        self,
        h: torch.Tensor,
        edge_index: torch.Tensor,
        n_nodes: int,
    ) -> torch.Tensor:
        """
        Args:
            h          : (N, in_dim) node features
            edge_index : (2, E) edge indices
            n_nodes    : total number of nodes N
        Returns:
            h_new: (N, out_dim)
        """
        # Add self-loops: Â = A + I
        self_loops = torch.arange(n_nodes, device=h.device).unsqueeze(0).repeat(2, 1)
        if edge_index.numel() > 0:
            adj_idx = torch.cat([edge_index, self_loops], dim=1)
        else:
            adj_idx = self_loops

        # Degree for normalization: D̂^{-1/2}
        degree = torch.zeros(n_nodes, device=h.device, dtype=torch.float32)
        degree.scatter_add_(0, adj_idx[0], torch.ones(adj_idx.size(1), device=h.device))
        d_inv_sqrt = degree.pow(-0.5).clamp(max=1e6)

        # Symmetric normalization: Â_norm = D̂^{-1/2} Â D̂^{-1/2}
        # Aggregation via scatter_add
        h_proj = self.W(h)   # (N, out_dim)
        src, dst = adj_idx[0], adj_idx[1]

        # Normalize source features
        msg = h_proj[dst] * d_inv_sqrt[dst].unsqueeze(-1)

        # Aggregate
        agg = torch.zeros_like(h_proj)
        agg.scatter_add_(0, src.unsqueeze(-1).expand_as(msg), msg)

        # Normalize aggregated features
        agg = agg * d_inv_sqrt.unsqueeze(-1)
        return F.relu(self.norm(agg))


# ─────────────────────────────────────────────────────────────────────────────
# Node feature extractor (patch features at nucleus locations)
# ─────────────────────────────────────────────────────────────────────────────

class NucleusFeatureExtractor(nn.Module):
    """
    Extract per-nucleus patch features from an image using ROI-pooling.
    A small CNN extracts a feature vector for each nucleus neighbourhood.
    """

    def __init__(self, in_channels: int = 3, out_dim: int = 64, patch_size: int = 16):
        super().__init__()
        self.patch_size = patch_size
        self.encoder = nn.Sequential(
            nn.Conv2d(in_channels, 32, 3, padding=1, bias=False),
            nn.BatchNorm2d(32), nn.ReLU(inplace=True),
            nn.Conv2d(32, 64, 3, padding=1, bias=False),
            nn.BatchNorm2d(64), nn.ReLU(inplace=True),
            nn.AdaptiveAvgPool2d(1),
            nn.Flatten(),
            nn.Linear(64, out_dim),
        )

    def forward(
        self,
        img: torch.Tensor,
        centroids: np.ndarray,
    ) -> torch.Tensor:
        """
        Args:
            img       : (1, C, H, W) single-image tensor
            centroids : (N, 2) nucleus centroids in pixel coordinates
        Returns:
            node_feats: (N, out_dim)
        """
        C, H, W = img.shape[1], img.shape[2], img.shape[3]
        half = self.patch_size // 2
        patches = []
        for (row, col) in centroids:
            r, c = int(row), int(col)
            r0 = max(0, r - half); r1 = min(H, r + half)
            c0 = max(0, c - half); c1 = min(W, c + half)
            patch = img[:, :, r0:r1, c0:c1]
            patch = F.interpolate(patch, size=(self.patch_size, self.patch_size),
                                  mode="bilinear", align_corners=False)
            patches.append(patch)

        if not patches:
            return torch.zeros(1, self.encoder[-1].out_features, device=img.device)

        patches = torch.cat(patches, dim=0)   # (N, C, patch_size, patch_size)
        return self.encoder(patches)           # (N, out_dim)


# ─────────────────────────────────────────────────────────────────────────────
# Full GCN encoder
# ─────────────────────────────────────────────────────────────────────────────

class CellGraphEncoder(nn.Module):
    """
    End-to-end Cell Graph Construction and GCN Encoding (Section 3.3).

    Pipeline per image:
      1. Detect nuclei (or accept external centroids)
      2. Build radius graph with threshold δ
      3. Extract per-node patch features
      4. Apply 2-layer GCN
      5. Global mean-pooling → graph-level feature vector

    Args:
        node_feat_dim : Dimension of per-nucleus features
        gcn_hidden    : Hidden dimension of GCN layers
        out_dim       : Output graph embedding dimension
        delta         : Edge distance threshold (pixels); BTO optimal = 42
        patch_size    : Neighbourhood patch size for feature extraction
    """

    def __init__(
        self,
        node_feat_dim: int = 64,
        gcn_hidden: int = 128,
        out_dim: int = 256,
        delta: float = 42.0,
        patch_size: int = 16,
    ):
        super().__init__()
        self.delta = delta

        self.node_extractor = NucleusFeatureExtractor(
            in_channels=3, out_dim=node_feat_dim, patch_size=patch_size
        )
        self.gcn1 = GCNLayer(node_feat_dim, gcn_hidden)
        self.gcn2 = GCNLayer(gcn_hidden, out_dim)
        self.readout = nn.Sequential(
            nn.Linear(out_dim, out_dim),
            nn.LayerNorm(out_dim),
            nn.ReLU(inplace=True),
        )
        self.out_dim = out_dim

    def forward(
        self,
        x: torch.Tensor,
        external_centroids: Optional[List[np.ndarray]] = None,
    ) -> torch.Tensor:
        """
        Args:
            x                  : (B, C, H, W) image batch
            external_centroids : Optional list of (N_i, 2) centroid arrays,
                                 one per image (e.g. from HoVer-Net)
        Returns:
            graph_feats: (B, out_dim) graph-level embeddings
        """
        B = x.size(0)
        batch_embeddings = []

        img_np = x.detach().cpu().numpy()  # (B, C, H, W)

        for i in range(B):
            # 1. Nucleus detection
            if external_centroids is not None:
                centroids = external_centroids[i]
            else:
                img_rgb = (img_np[i].transpose(1, 2, 0) * 255).clip(0, 255).astype(np.uint8)
                centroids = detect_nuclei_simple(img_rgb)

            n_nodes = len(centroids)

            # 2. Build graph
            edge_index, _ = build_radius_graph(centroids, delta=self.delta)
            edge_index = edge_index.to(x.device)

            # 3. Node features
            node_feats = self.node_extractor(x[i:i+1], centroids)   # (N, node_feat_dim)

            # 4. GCN
            h = self.gcn1(node_feats, edge_index, n_nodes)
            h = self.gcn2(h, edge_index, n_nodes)

            # 5. Global mean-pooling
            graph_emb = h.mean(dim=0, keepdim=True)  # (1, out_dim)
            batch_embeddings.append(graph_emb)

        graph_feats = torch.cat(batch_embeddings, dim=0)  # (B, out_dim)
        return self.readout(graph_feats)
