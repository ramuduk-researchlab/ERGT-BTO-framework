"""
models/multiscale_radiomics.py
==============================
Multi-Scale Radiomic Feature Extraction (Section 3.3.1).

Three parallel convolutional branches with kernel sizes k ∈ {3, 5, 7}:
  - Branch 1 (3×3): Nuclear scale – nuclear irregularity, mitotic activity
  - Branch 2 (5×5): Cellular scale – glandular lumens, ductal organization
  - Branch 3 (7×7): Tissue scale – stromal invasion, architectural disruption

Each branch follows:  Conv(k) → BN → ReLU → Conv(k) → BN → ReLU → GAP

Handcrafted radiomic features (GLCM + LBP) are extracted and fused
with learned CNN features per branch (Section 3.3.1 Eqs. 3–4).

Final output: concatenation of all three branches' feature vectors.
"""

from __future__ import annotations

import math
from typing import List, Tuple

import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
from skimage.feature import local_binary_pattern
from skimage.feature import graycomatrix, graycoprops


# ─────────────────────────────────────────────────────────────────────────────
# GLCM + LBP handcrafted feature extractor
# ─────────────────────────────────────────────────────────────────────────────

class HandcraftedRadiomics:
    """
    Compute GLCM and LBP features from a batch of images.

    GLCM properties extracted (Section 3.3.1, Eq. 3):
      - energy, contrast, homogeneity, entropy, correlation

    LBP:
      - radius=1,3; n_points=8×radius; uniform patterns

    Both are concatenated into a fixed-length feature vector per image.
    """

    def __init__(
        self,
        glcm_distances: List[int] = [1, 3, 5],
        glcm_angles: List[float] = [0, np.pi / 4, np.pi / 2, 3 * np.pi / 4],
        lbp_radii: List[int] = [1, 3],
        n_bins: int = 32,
    ):
        self.glcm_distances = glcm_distances
        self.glcm_angles = glcm_angles
        self.lbp_radii = lbp_radii
        self.n_bins = n_bins

        # Pre-compute feature vector length
        n_glcm_props = 5          # energy, contrast, homogeneity, entropy, correlation
        n_glcm = n_glcm_props * len(glcm_distances) * len(glcm_angles)
        n_lbp  = n_bins * len(lbp_radii)
        self.feature_dim = n_glcm + n_lbp

    def _extract_single(self, img_gray: np.ndarray) -> np.ndarray:
        """Extract features from a single grayscale image (H×W, uint8)."""
        features = []

        # ── GLCM ────────────────────────────────────────────────────────────
        for d in self.glcm_distances:
            glcm = graycomatrix(
                img_gray, distances=[d], angles=self.glcm_angles,
                levels=256, symmetric=True, normed=True,
            )  # shape: (256, 256, 1, len(angles))
            for prop in ("energy", "contrast", "homogeneity", "correlation", "entropy"):
                if prop == "entropy":
                    eps = 1e-10
                    ent = -np.sum(glcm * np.log2(glcm + eps), axis=(0, 1))  # (1, n_angles)
                    features.extend(ent.flatten().tolist())
                else:
                    values = graycoprops(glcm, prop)  # (1, n_angles)
                    features.extend(values.flatten().tolist())

        # ── LBP ─────────────────────────────────────────────────────────────
        for r in self.lbp_radii:
            n_points = 8 * r
            lbp = local_binary_pattern(img_gray, n_points, r, method="uniform")
            hist, _ = np.histogram(lbp.ravel(), bins=self.n_bins, range=(0, n_points + 2))
            hist = hist.astype(float)
            hist /= (hist.sum() + 1e-8)
            features.extend(hist.tolist())

        return np.array(features, dtype=np.float32)

    def __call__(self, images: torch.Tensor) -> torch.Tensor:
        """
        Args:
            images: (B, C, H, W) tensor in any range (we take luminance)
        Returns:
            features: (B, feature_dim) tensor
        """
        B = images.size(0)
        feats = []
        imgs_np = images.detach().cpu().numpy()  # (B, C, H, W)

        for b in range(B):
            # Convert to grayscale uint8
            img = imgs_np[b].transpose(1, 2, 0)   # H×W×C
            img_min, img_max = img.min(), img.max()
            img_norm = (img - img_min) / (img_max - img_min + 1e-8)
            gray = (0.2989 * img_norm[:, :, 0] +
                    0.5870 * img_norm[:, :, 1] +
                    0.1140 * img_norm[:, :, 2])
            gray_uint8 = (gray * 255).astype(np.uint8)
            feats.append(self._extract_single(gray_uint8))

        return torch.tensor(np.stack(feats, axis=0), dtype=torch.float32,
                            device=images.device)


# ─────────────────────────────────────────────────────────────────────────────
# Single-scale convolutional branch
# ─────────────────────────────────────────────────────────────────────────────

class ConvBranch(nn.Module):
    """
    One multi-scale radiomic branch (Eq. 2):

        F_k = ReLU(BN(W_k2 * ReLU(BN(W_k1 * I)))) → GAP → fc

    Args:
        kernel_size : k ∈ {3, 5, 7}
        in_channels : input channels (3 for RGB)
        base_filters: number of conv filters in first layer
        out_dim     : output feature dimension after FC projection
    """

    def __init__(
        self,
        kernel_size: int,
        in_channels: int = 3,
        base_filters: int = 64,
        out_dim: int = 256,
    ):
        super().__init__()
        pad = kernel_size // 2

        self.conv_block = nn.Sequential(
            # Layer 1
            nn.Conv2d(in_channels, base_filters, kernel_size, padding=pad, bias=False),
            nn.BatchNorm2d(base_filters),
            nn.ReLU(inplace=True),
            # Layer 2
            nn.Conv2d(base_filters, base_filters * 2, kernel_size, padding=pad, bias=False),
            nn.BatchNorm2d(base_filters * 2),
            nn.ReLU(inplace=True),
            # Layer 3
            nn.Conv2d(base_filters * 2, base_filters * 4, kernel_size, padding=pad, bias=False),
            nn.BatchNorm2d(base_filters * 4),
            nn.ReLU(inplace=True),
            # Global Average Pooling
            nn.AdaptiveAvgPool2d(1),
        )
        self.fc = nn.Sequential(
            nn.Flatten(),
            nn.Linear(base_filters * 4, out_dim),
            nn.ReLU(inplace=True),
        )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.fc(self.conv_block(x))


# ─────────────────────────────────────────────────────────────────────────────
# Full multi-scale radiomic feature extractor
# ─────────────────────────────────────────────────────────────────────────────

class MultiScaleRadiomicExtractor(nn.Module):
    """
    Multi-Scale Radiomic Feature Extractor with three parallel CNN branches
    and handcrafted GLCM/LBP features (Section 3.3.1).

    Architecture:
        Input (B, 3, 224, 224)
            │
            ├── Branch1 (k=3, nuclear scale)    → (B, branch_dim)
            ├── Branch2 (k=5, cellular scale)   → (B, branch_dim)
            └── Branch3 (k=7, tissue scale)     → (B, branch_dim)
            │
            ├── GLCM+LBP handcrafted features   → (B, handcraft_dim)
            │
            └── Fusion FC                        → (B, out_dim)

    Args:
        in_channels   : Input image channels (default 3)
        base_filters  : Base number of conv filters per branch
        branch_dim    : Output dimension of each CNN branch
        out_dim       : Final fused feature dimension
        use_handcraft : Whether to include GLCM+LBP features
    """

    def __init__(
        self,
        in_channels: int = 3,
        base_filters: int = 64,
        branch_dim: int = 256,
        out_dim: int = 512,
        use_handcraft: bool = True,
    ):
        super().__init__()
        self.use_handcraft = use_handcraft

        # Three parallel branches
        self.branch1 = ConvBranch(3, in_channels, base_filters, branch_dim)  # nuclear
        self.branch2 = ConvBranch(5, in_channels, base_filters, branch_dim)  # cellular
        self.branch3 = ConvBranch(7, in_channels, base_filters, branch_dim)  # tissue

        # Handcrafted radiomics
        if use_handcraft:
            self.handcrafted = HandcraftedRadiomics()
            handcraft_dim = self.handcrafted.feature_dim
            self.handcraft_proj = nn.Sequential(
                nn.Linear(handcraft_dim, 128),
                nn.ReLU(inplace=True),
            )
            fusion_in_dim = 3 * branch_dim + 128
        else:
            fusion_in_dim = 3 * branch_dim

        # Feature fusion
        self.fusion = nn.Sequential(
            nn.Linear(fusion_in_dim, out_dim),
            nn.LayerNorm(out_dim),
            nn.ReLU(inplace=True),
            nn.Dropout(0.3),
        )

        self.out_dim = out_dim

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        """
        Args:
            x: (B, 3, H, W) input image tensor
        Returns:
            features: (B, out_dim) fused radiomic features
        """
        f1 = self.branch1(x)   # (B, branch_dim)
        f2 = self.branch2(x)   # (B, branch_dim)
        f3 = self.branch3(x)   # (B, branch_dim)

        parts = [f1, f2, f3]

        if self.use_handcraft:
            hc = self.handcrafted(x)                 # (B, handcraft_dim)
            hc = self.handcraft_proj(hc)             # (B, 128)
            parts.append(hc)

        fused = torch.cat(parts, dim=-1)             # (B, fusion_in_dim)
        return self.fusion(fused)                    # (B, out_dim)
