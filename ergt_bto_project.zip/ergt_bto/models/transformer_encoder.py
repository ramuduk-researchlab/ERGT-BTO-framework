"""
models/transformer_encoder.py
==============================
Transformer-Based Contextual Aggregation (Section 3.3, Section 2.5).

Implements a multi-head self-attention Transformer encoder over tissue
sub-regions to model long-range contextual dependencies (Section 3.3.3).

Features:
  - Custom 2D spatial positional encoding for histopathology patches
  - Standard Transformer Encoder layers (PyTorch nn.TransformerEncoder)
  - [CLS] token for global representation
  - Attention weights stored for rollout explainability (Section 3.3.5)
"""

from __future__ import annotations

import math
from typing import List, Optional, Tuple

import torch
import torch.nn as nn
import torch.nn.functional as F


# ─────────────────────────────────────────────────────────────────────────────
# 2D Spatial Positional Encoding
# ─────────────────────────────────────────────────────────────────────────────

class SpatialPositionalEncoding2D(nn.Module):
    """
    2D learnable positional encoding for spatial tissue sub-regions.

    Encodes (row, col) patch position into a d_model-dimensional vector.
    Uses separate sinusoidal encodings for row and column, concatenated.
    """

    def __init__(self, d_model: int, max_h: int = 14, max_w: int = 14):
        super().__init__()
        assert d_model % 2 == 0, "d_model must be even for 2D pos encoding"
        half = d_model // 2

        # Build row encoding (half dimensions)
        pe_h = torch.zeros(max_h, half)
        pos_h = torch.arange(max_h, dtype=torch.float32).unsqueeze(1)
        div_term = torch.exp(torch.arange(0, half, 2, dtype=torch.float32)
                             * (-math.log(10000.0) / half))
        pe_h[:, 0::2] = torch.sin(pos_h * div_term)
        pe_h[:, 1::2] = torch.cos(pos_h * div_term)

        # Build col encoding (half dimensions)
        pe_w = torch.zeros(max_w, half)
        pos_w = torch.arange(max_w, dtype=torch.float32).unsqueeze(1)
        pe_w[:, 0::2] = torch.sin(pos_w * div_term)
        pe_w[:, 1::2] = torch.cos(pos_w * div_term)

        self.register_buffer("pe_h", pe_h)  # (max_h, half)
        self.register_buffer("pe_w", pe_w)  # (max_w, half)
        self.max_h = max_h
        self.max_w = max_w
        self.d_model = d_model

    def forward(self, seq_len: int, h: int, w: int) -> torch.Tensor:
        """
        Returns positional encoding for a grid of h×w patches.
        Shape: (h*w + 1, d_model) — +1 for [CLS] token (zeros at position 0).
        """
        pe_grid = []
        for row in range(h):
            for col in range(w):
                r_enc = self.pe_h[row % self.max_h]   # (half,)
                c_enc = self.pe_w[col % self.max_w]   # (half,)
                pe_grid.append(torch.cat([r_enc, c_enc], dim=0))

        pe_patches = torch.stack(pe_grid, dim=0)   # (h*w, d_model)
        cls_pos = torch.zeros(1, self.d_model, device=pe_patches.device)
        return torch.cat([cls_pos, pe_patches], dim=0)  # (h*w+1, d_model)


# ─────────────────────────────────────────────────────────────────────────────
# Patch embedding (linear projection of image patches)
# ─────────────────────────────────────────────────────────────────────────────

class PatchEmbedding(nn.Module):
    """
    Divide image into non-overlapping patches and project each to d_model dims.

    Args:
        img_size   : Input image size (assumed square)
        patch_size : Patch size (e.g. 16 → 14×14 = 196 patches for img=224)
        in_channels: Input channels
        d_model    : Embedding dimension
    """

    def __init__(
        self,
        img_size: int = 224,
        patch_size: int = 16,
        in_channels: int = 3,
        d_model: int = 256,
    ):
        super().__init__()
        self.img_size = img_size
        self.patch_size = patch_size
        self.n_patches_h = img_size // patch_size
        self.n_patches_w = img_size // patch_size
        self.n_patches = self.n_patches_h * self.n_patches_w
        self.d_model = d_model

        self.proj = nn.Conv2d(
            in_channels, d_model,
            kernel_size=patch_size, stride=patch_size,
        )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        """
        Args:
            x: (B, C, H, W)
        Returns:
            patches: (B, n_patches, d_model)
        """
        x = self.proj(x)                   # (B, d_model, nh, nw)
        x = x.flatten(2).transpose(1, 2)   # (B, n_patches, d_model)
        return x


# ─────────────────────────────────────────────────────────────────────────────
# Transformer Encoder with attention storage
# ─────────────────────────────────────────────────────────────────────────────

class AttentionStoringTransformerLayer(nn.Module):
    """
    Single transformer encoder layer that stores attention weights
    for attention rollout explainability (Section 3.3.5).
    """

    def __init__(self, d_model: int, n_heads: int, dim_ff: int, dropout: float = 0.1):
        super().__init__()
        self.attn = nn.MultiheadAttention(
            d_model, n_heads, dropout=dropout, batch_first=True
        )
        self.ff = nn.Sequential(
            nn.Linear(d_model, dim_ff),
            nn.GELU(),
            nn.Dropout(dropout),
            nn.Linear(dim_ff, d_model),
        )
        self.norm1 = nn.LayerNorm(d_model)
        self.norm2 = nn.LayerNorm(d_model)
        self.dropout = nn.Dropout(dropout)

        self.last_attn_weights: Optional[torch.Tensor] = None

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        """
        Args:
            x: (B, seq_len, d_model)
        Returns:
            x: (B, seq_len, d_model)
        """
        attn_out, attn_weights = self.attn(x, x, x, need_weights=True, average_attn_weights=False)
        self.last_attn_weights = attn_weights.detach()   # (B, n_heads, seq, seq)
        x = self.norm1(x + self.dropout(attn_out))
        x = self.norm2(x + self.ff(x))
        return x


class ContextualTransformerEncoder(nn.Module):
    """
    Transformer-Based Contextual Aggregation module (Section 3.3.3).

    Takes an input feature map, divides into patches, applies multi-head
    self-attention across patches to model long-range tissue context.

    Architecture:
        Image (B, 3, 224, 224)
          → PatchEmbedding   → (B, 196, d_model)
          → [CLS] token prepended → (B, 197, d_model)
          → Spatial positional encoding added
          → L × TransformerEncoder layers
          → [CLS] output  → (B, d_model) → FC → (B, out_dim)

    Args:
        img_size   : Input image size
        patch_size : Patch size (default 16)
        in_channels: Input channels
        d_model    : Transformer embedding dimension
        n_heads    : Number of attention heads
        n_layers   : Number of transformer layers
        dim_ff     : Feed-forward hidden dimension
        out_dim    : Final output dimension
        dropout    : Dropout rate
    """

    def __init__(
        self,
        img_size: int = 224,
        patch_size: int = 16,
        in_channels: int = 3,
        d_model: int = 256,
        n_heads: int = 8,
        n_layers: int = 4,
        dim_ff: int = 1024,
        out_dim: int = 256,
        dropout: float = 0.1,
    ):
        super().__init__()
        self.d_model = d_model

        # Patch embedding
        self.patch_embed = PatchEmbedding(img_size, patch_size, in_channels, d_model)
        n_patches_h = img_size // patch_size
        n_patches_w = img_size // patch_size

        # [CLS] token
        self.cls_token = nn.Parameter(torch.zeros(1, 1, d_model))
        nn.init.trunc_normal_(self.cls_token, std=0.02)

        # Positional encoding
        self.pos_enc = SpatialPositionalEncoding2D(d_model, n_patches_h, n_patches_w)

        # Transformer layers
        self.layers = nn.ModuleList([
            AttentionStoringTransformerLayer(d_model, n_heads, dim_ff, dropout)
            for _ in range(n_layers)
        ])

        self.norm = nn.LayerNorm(d_model)

        # Output projection
        self.head = nn.Sequential(
            nn.Linear(d_model, out_dim),
            nn.LayerNorm(out_dim),
            nn.ReLU(inplace=True),
        )

        self.out_dim = out_dim
        self.n_patches_h = n_patches_h
        self.n_patches_w = n_patches_w

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        """
        Args:
            x: (B, 3, H, W) images
        Returns:
            context_feat: (B, out_dim) contextual representation
        """
        B = x.size(0)

        # Patch embedding
        patches = self.patch_embed(x)   # (B, N, d_model)
        N = patches.size(1)

        # Prepend [CLS]
        cls_tokens = self.cls_token.expand(B, -1, -1)
        tokens = torch.cat([cls_tokens, patches], dim=1)   # (B, N+1, d_model)

        # Add positional encoding
        pos = self.pos_enc(N, self.n_patches_h, self.n_patches_w)  # (N+1, d_model)
        tokens = tokens + pos.unsqueeze(0)

        # Transformer layers
        for layer in self.layers:
            tokens = layer(tokens)

        tokens = self.norm(tokens)

        # [CLS] token as global representation
        cls_out = tokens[:, 0]   # (B, d_model)
        return self.head(cls_out)  # (B, out_dim)

    def get_attention_maps(self) -> List[torch.Tensor]:
        """Return stored attention weights from all layers for rollout."""
        return [
            layer.last_attn_weights
            for layer in self.layers
            if layer.last_attn_weights is not None
        ]
