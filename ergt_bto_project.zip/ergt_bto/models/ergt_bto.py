"""
models/ergt_bto.py
==================
Full ERGT-BTO Model (Section 3.3).

Integrates:
  1. MultiScaleRadiomicExtractor  – three parallel CNN branches + GLCM/LBP
  2. CellGraphEncoder             – nucleus graph + 2-layer GCN
  3. ContextualTransformerEncoder – multi-head self-attention over patches
  4. Feature fusion + BTO-optimized FC classifier
  5. Dual-layer explainability hooks (SHAP, attention rollout)

Architecture diagram (Section 3.3, Fig. 2):
  Input (B, 3, 224, 224)
       │
       ├── MultiScaleRadiomicExtractor → (B, radiomic_dim)
       ├── CellGraphEncoder            → (B, gcn_dim)
       └── ContextualTransformerEncoder→ (B, transformer_dim)
       │
       └── Concat → (B, radiomic_dim + gcn_dim + transformer_dim)
               → FC (BTO-tuned) → Dropout → FC → LogSoftmax
"""

from __future__ import annotations

from typing import Dict, List, Optional, Tuple, Any

import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F

from models.multiscale_radiomics import MultiScaleRadiomicExtractor
from models.gcn_encoder import CellGraphEncoder
from models.transformer_encoder import ContextualTransformerEncoder


class ERGTBTOModel(nn.Module):
    """
    Explainable Radiomic Graph Transformer with BTO Optimization.

    Args
    ----
    num_classes          : Number of output classes (4 for BACH)
    img_size             : Input image spatial size (default 224)
    radiomic_out_dim     : Feature dimension from multi-scale radiomic branch
    gcn_out_dim          : Feature dimension from GCN branch
    transformer_out_dim  : Feature dimension from Transformer branch
    gcn_hidden           : GCN hidden layer dimension (BTO-tuned; default 128)
    gcn_delta            : Edge distance threshold in pixels (BTO optimal = 42)
    transformer_heads    : Number of attention heads (BTO-tuned; default 8)
    transformer_layers   : Number of transformer layers (BTO-tuned; default 4)
    transformer_d_model  : Transformer embedding dimension
    dropout              : Dropout probability for classifier (BTO-tuned)
    use_handcraft        : Include GLCM/LBP features (default True)
    """

    def __init__(
        self,
        num_classes: int = 4,
        img_size: int = 224,
        radiomic_out_dim: int = 512,
        gcn_out_dim: int = 256,
        transformer_out_dim: int = 256,
        gcn_hidden: int = 128,
        gcn_delta: float = 42.0,
        transformer_heads: int = 8,
        transformer_layers: int = 4,
        transformer_d_model: int = 256,
        dropout: float = 0.3,
        use_handcraft: bool = True,
    ):
        super().__init__()
        self.num_classes = num_classes

        # ── 1. Multi-Scale Radiomic Feature Extractor ─────────────────────────
        self.radiomic_extractor = MultiScaleRadiomicExtractor(
            in_channels=3,
            base_filters=64,
            branch_dim=128,
            out_dim=radiomic_out_dim,
            use_handcraft=use_handcraft,
        )

        # ── 2. Cell Graph Encoder ─────────────────────────────────────────────
        self.graph_encoder = CellGraphEncoder(
            node_feat_dim=64,
            gcn_hidden=gcn_hidden,
            out_dim=gcn_out_dim,
            delta=gcn_delta,
            patch_size=16,
        )

        # ── 3. Transformer-Based Contextual Encoder ───────────────────────────
        self.transformer_encoder = ContextualTransformerEncoder(
            img_size=img_size,
            patch_size=16,
            in_channels=3,
            d_model=transformer_d_model,
            n_heads=transformer_heads,
            n_layers=transformer_layers,
            dim_ff=transformer_d_model * 4,
            out_dim=transformer_out_dim,
            dropout=0.1,
        )

        # ── 4. Feature Fusion + BTO-Optimized Classifier ─────────────────────
        fusion_dim = radiomic_out_dim + gcn_out_dim + transformer_out_dim
        self.classifier = nn.Sequential(
            nn.Linear(fusion_dim, 512),
            nn.LayerNorm(512),
            nn.ReLU(inplace=True),
            nn.Dropout(dropout),
            nn.Linear(512, 128),
            nn.LayerNorm(128),
            nn.ReLU(inplace=True),
            nn.Dropout(dropout / 2),
            nn.Linear(128, num_classes),
        )

        # Feature storage for SHAP analysis
        self._last_features: Optional[torch.Tensor] = None

        self._init_weights()

    def _init_weights(self) -> None:
        for m in self.modules():
            if isinstance(m, nn.Linear):
                nn.init.trunc_normal_(m.weight, std=0.02)
                if m.bias is not None:
                    nn.init.zeros_(m.bias)
            elif isinstance(m, (nn.BatchNorm2d, nn.LayerNorm)):
                nn.init.ones_(m.weight)
                nn.init.zeros_(m.bias)

    def forward(
        self,
        x: torch.Tensor,
        external_centroids: Optional[List[np.ndarray]] = None,
        return_features: bool = False,
    ) -> torch.Tensor | Tuple[torch.Tensor, torch.Tensor]:
        """
        Forward pass.

        Args:
            x                  : (B, 3, H, W) input images
            external_centroids : Optional nucleus centroids from HoVer-Net
            return_features    : If True, also return the fused feature vector

        Returns:
            logits   : (B, num_classes)
            features : (B, fusion_dim) — only if return_features=True
        """
        # Branch 1: Multi-scale radiomic features
        radiomic_feat = self.radiomic_extractor(x)          # (B, radiomic_out_dim)

        # Branch 2: Cell graph features
        graph_feat = self.graph_encoder(x, external_centroids)  # (B, gcn_out_dim)

        # Branch 3: Transformer contextual features
        context_feat = self.transformer_encoder(x)          # (B, transformer_out_dim)

        # Fusion
        fused = torch.cat([radiomic_feat, graph_feat, context_feat], dim=-1)  # (B, fusion_dim)
        self._last_features = fused.detach()

        logits = self.classifier(fused)

        if return_features:
            return logits, fused
        return logits

    def get_attention_maps(self) -> List[torch.Tensor]:
        """Return transformer attention maps for rollout explainability."""
        return self.transformer_encoder.get_attention_maps()

    @classmethod
    def from_bto_config(cls, bto_params: Dict[str, Any], **kwargs) -> "ERGTBTOModel":
        """
        Instantiate model from BTO-optimized hyperparameter dictionary.

        Args:
            bto_params : Output from BluefinTrevallyOptimizer.optimize()
            **kwargs   : Additional fixed kwargs (e.g. num_classes)

        Returns:
            ERGTBTOModel instance
        """
        return cls(
            gcn_hidden=int(bto_params.get("gcn_hidden_dim", 128)),
            gcn_delta=float(bto_params.get("delta_px", 42.0)),
            transformer_heads=int(bto_params.get("transformer_heads", 8)),
            transformer_layers=int(bto_params.get("transformer_layers", 4)),
            dropout=float(bto_params.get("dropout", 0.3)),
            **kwargs,
        )

    def count_parameters(self) -> int:
        return sum(p.numel() for p in self.parameters() if p.requires_grad)

    def print_summary(self) -> None:
        total = self.count_parameters()
        print(f"\n{'─'*50}")
        print(f"  ERGT-BTO Model Summary")
        print(f"{'─'*50}")
        print(f"  Radiomic Extractor : {sum(p.numel() for p in self.radiomic_extractor.parameters()):>12,}")
        print(f"  Graph Encoder      : {sum(p.numel() for p in self.graph_encoder.parameters()):>12,}")
        print(f"  Transformer Encoder: {sum(p.numel() for p in self.transformer_encoder.parameters()):>12,}")
        print(f"  Classifier         : {sum(p.numel() for p in self.classifier.parameters()):>12,}")
        print(f"{'─'*50}")
        print(f"  Total Parameters   : {total:>12,}  (~{total/1e6:.1f}M)")
        print(f"{'─'*50}\n")
