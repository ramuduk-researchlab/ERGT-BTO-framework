"""
models/baselines.py
====================
Baseline models used in the comparative study (Table 8, Section 4.8).

Implements lightweight wrappers around standard architectures:
  - VGG-16 (transfer learning, fine-tuned last 2 blocks)
  - ResNet-50 (transfer learning)
  - InceptionV3 (transfer learning)
  - EfficientNet-B4 (transfer learning)
  - ViT-B/16 (Vision Transformer, from scratch or pretrained)
  - GCN-only baseline (no radiomic or transformer)
  - RadiomicNet (multi-scale CNN only, no GCN/Transformer)

Each baseline uses the same 4-class head and training protocol.
"""

from __future__ import annotations

from typing import Optional

import torch
import torch.nn as nn


# ─────────────────────────────────────────────────────────────────────────────
# Transfer Learning Baselines
# ─────────────────────────────────────────────────────────────────────────────

def build_vgg16(num_classes: int = 4, pretrained: bool = True) -> nn.Module:
    """
    VGG-16 with fine-tuned last 2 convolutional blocks (Section 4.8.1).
    Classifier head replaced for 4-class output.
    """
    from torchvision.models import vgg16, VGG16_Weights
    weights = VGG16_Weights.IMAGENET1K_V1 if pretrained else None
    model = vgg16(weights=weights)

    # Freeze early layers; fine-tune from block 4 onward
    for name, param in model.features.named_parameters():
        layer_num = int(name.split(".")[0])
        param.requires_grad = layer_num >= 17  # block 4 starts at layer 17

    # Replace classifier
    model.classifier = nn.Sequential(
        nn.Linear(512 * 7 * 7, 4096),
        nn.ReLU(inplace=True),
        nn.Dropout(0.5),
        nn.Linear(4096, 512),
        nn.ReLU(inplace=True),
        nn.Dropout(0.5),
        nn.Linear(512, num_classes),
    )
    return model


def build_resnet50(num_classes: int = 4, pretrained: bool = True) -> nn.Module:
    """ResNet-50 with fine-tuned last 2 residual stages."""
    from torchvision.models import resnet50, ResNet50_Weights
    weights = ResNet50_Weights.IMAGENET1K_V1 if pretrained else None
    model = resnet50(weights=weights)

    # Freeze early stages
    for name, param in model.named_parameters():
        if "layer3" not in name and "layer4" not in name and "fc" not in name:
            param.requires_grad = False

    model.fc = nn.Sequential(
        nn.Linear(model.fc.in_features, 256),
        nn.ReLU(inplace=True),
        nn.Dropout(0.4),
        nn.Linear(256, num_classes),
    )
    return model


def build_inceptionv3(num_classes: int = 4, pretrained: bool = True) -> nn.Module:
    """InceptionV3 with fine-tuned last inception blocks."""
    from torchvision.models import inception_v3, Inception_V3_Weights
    weights = Inception_V3_Weights.IMAGENET1K_V1 if pretrained else None
    model = inception_v3(weights=weights, aux_logits=False)

    # Freeze early layers
    for name, param in model.named_parameters():
        if "Mixed_7" not in name and "fc" not in name:
            param.requires_grad = False

    model.fc = nn.Sequential(
        nn.Linear(model.fc.in_features, 256),
        nn.ReLU(inplace=True),
        nn.Dropout(0.4),
        nn.Linear(256, num_classes),
    )
    return model


def build_efficientnet_b4(num_classes: int = 4, pretrained: bool = True) -> nn.Module:
    """EfficientNet-B4 with fine-tuned last 3 blocks."""
    from torchvision.models import efficientnet_b4, EfficientNet_B4_Weights
    weights = EfficientNet_B4_Weights.IMAGENET1K_V1 if pretrained else None
    model = efficientnet_b4(weights=weights)

    # Freeze all but last 3 MBConv blocks + classifier
    total_blocks = len(model.features)
    for i, block in enumerate(model.features):
        if i < total_blocks - 3:
            for param in block.parameters():
                param.requires_grad = False

    in_features = model.classifier[-1].in_features
    model.classifier = nn.Sequential(
        nn.Dropout(0.4),
        nn.Linear(in_features, num_classes),
    )
    return model


def build_vit_b16(num_classes: int = 4, pretrained: bool = True) -> nn.Module:
    """
    Vision Transformer ViT-B/16 from torchvision.
    Fine-tuned classification head.
    """
    from torchvision.models import vit_b_16, ViT_B_16_Weights
    weights = ViT_B_16_Weights.IMAGENET1K_V1 if pretrained else None
    model = vit_b_16(weights=weights)

    # Replace the classification head
    model.heads = nn.Sequential(
        nn.Linear(model.hidden_dim, 256),
        nn.ReLU(inplace=True),
        nn.Dropout(0.3),
        nn.Linear(256, num_classes),
    )
    return model


# ─────────────────────────────────────────────────────────────────────────────
# Ablation-specific baselines
# ─────────────────────────────────────────────────────────────────────────────

class RadiomicNetBaseline(nn.Module):
    """
    Multi-scale CNN only (no GCN, no Transformer).
    Corresponds to "MultiScale-Radiomic" row in Table 10.
    """

    def __init__(self, num_classes: int = 4):
        super().__init__()
        from models.multiscale_radiomics import MultiScaleRadiomicExtractor
        self.extractor = MultiScaleRadiomicExtractor(out_dim=512)
        self.head = nn.Linear(512, num_classes)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.head(self.extractor(x))


class GCNOnlyBaseline(nn.Module):
    """
    GCN branch only (no radiomic CNN, no Transformer).
    Corresponds to "GCN (Graph-only)" row in Table 8.
    """

    def __init__(self, num_classes: int = 4, delta: float = 42.0):
        super().__init__()
        from models.gcn_encoder import CellGraphEncoder
        self.encoder = CellGraphEncoder(gcn_hidden=128, out_dim=256, delta=delta)
        self.head = nn.Sequential(
            nn.Linear(256, 128),
            nn.ReLU(inplace=True),
            nn.Dropout(0.3),
            nn.Linear(128, num_classes),
        )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.head(self.encoder(x))


class TransformerOnlyBaseline(nn.Module):
    """
    Transformer branch only (no radiomic CNN, no GCN).
    Used in ablation study (Table 10).
    """

    def __init__(self, num_classes: int = 4):
        super().__init__()
        from models.transformer_encoder import ContextualTransformerEncoder
        self.encoder = ContextualTransformerEncoder(out_dim=256)
        self.head = nn.Sequential(
            nn.Linear(256, 128),
            nn.ReLU(inplace=True),
            nn.Dropout(0.3),
            nn.Linear(128, num_classes),
        )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.head(self.encoder(x))


# ─────────────────────────────────────────────────────────────────────────────
# Factory
# ─────────────────────────────────────────────────────────────────────────────

BASELINE_REGISTRY = {
    "vgg16":           build_vgg16,
    "resnet50":        build_resnet50,
    "inceptionv3":     build_inceptionv3,
    "efficientnet_b4": build_efficientnet_b4,
    "vit_b16":         build_vit_b16,
    "radiomic_only":   lambda nc=4, **kw: RadiomicNetBaseline(nc),
    "gcn_only":        lambda nc=4, **kw: GCNOnlyBaseline(nc),
    "transformer_only":lambda nc=4, **kw: TransformerOnlyBaseline(nc),
}


def build_baseline(name: str, num_classes: int = 4, pretrained: bool = True) -> nn.Module:
    """
    Factory function to build a baseline model by name.

    Args:
        name        : One of the keys in BASELINE_REGISTRY
        num_classes : Number of output classes
        pretrained  : Whether to load ImageNet weights (where applicable)

    Returns:
        nn.Module
    """
    if name not in BASELINE_REGISTRY:
        raise ValueError(
            f"Unknown baseline '{name}'. Available: {list(BASELINE_REGISTRY.keys())}"
        )
    builder = BASELINE_REGISTRY[name]
    try:
        return builder(num_classes, pretrained=pretrained)
    except TypeError:
        return builder(num_classes)
