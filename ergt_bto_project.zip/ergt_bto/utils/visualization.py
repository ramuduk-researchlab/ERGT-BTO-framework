"""
utils/visualization.py
=======================
Visualization utilities for ERGT-BTO (Section 4.3, 4.6, 4.13).

Provides:
  - BTO convergence curve plotting (Fig. 6)
  - t-SNE feature space visualization (Fig. 7)
  - Per-class precision/recall bar chart (Fig. 9)
  - Comparative bar chart vs baselines (Table 8)
  - Attention head diversity heatmap
  - Training history curves (loss + metrics)
"""

from __future__ import annotations

from typing import Dict, List, Optional, Tuple

import numpy as np

try:
    import matplotlib.pyplot as plt
    import matplotlib.patches as mpatches
    import seaborn as sns
    MPL_AVAILABLE = True
except ImportError:
    MPL_AVAILABLE = False
    print("[Warning] matplotlib/seaborn not installed.")

try:
    from sklearn.manifold import TSNE
    SKLEARN_AVAILABLE = True
except ImportError:
    SKLEARN_AVAILABLE = False


LABEL_NAMES = ["Normal", "Benign", "In-Situ", "Invasive"]
CLASS_COLORS = ["#2196F3", "#4CAF50", "#FF9800", "#F44336"]


# ─────────────────────────────────────────────────────────────────────────────
# BTO Convergence Curve (Fig. 6)
# ─────────────────────────────────────────────────────────────────────────────

def plot_bto_convergence(
    bto_history: List[Dict],
    save_path: Optional[str] = None,
    compare_baselines: Optional[Dict[str, List[float]]] = None,
) -> None:
    """
    Plot BTO convergence curve alongside optional baseline optimizers.

    Args:
        bto_history        : List of iteration dicts from BTO (each has 'best_fitness')
        save_path          : Optional save path
        compare_baselines  : Dict of {name: [fitness_per_iter]} for PSO, GWO, WOA, etc.
    """
    if not MPL_AVAILABLE:
        return

    fig, axes = plt.subplots(1, 2, figsize=(14, 5))

    # ── Left: fitness convergence ─────────────────────────────────────────────
    ax = axes[0]
    iters = [h["iteration"] for h in bto_history]
    fitnesses = [h["best_fitness"] for h in bto_history]
    ax.plot(iters, fitnesses, color="#E91E63", lw=2.5, label="BTO (proposed)", zorder=5)

    if compare_baselines:
        baseline_styles = {
            "PSO": ("--", "#2196F3"),
            "GWO": ("-.", "#4CAF50"),
            "WOA": (":",  "#FF9800"),
            "SCA": ("--", "#9C27B0"),
        }
        for name, scores in compare_baselines.items():
            style, color = baseline_styles.get(name, ("--", "gray"))
            ax.plot(range(1, len(scores)+1), scores,
                    linestyle=style, color=color, lw=1.5, label=name, alpha=0.75)

    ax.set_xlabel("Iteration", fontsize=12)
    ax.set_ylabel("Best Validation F1-Score", fontsize=12)
    ax.set_title("BTO Convergence Curve", fontsize=13, fontweight="bold")
    ax.legend(fontsize=10)
    ax.grid(alpha=0.3)
    ax.set_ylim(bottom=0)

    # ── Right: α decay schedule ──────────────────────────────────────────────
    ax2 = axes[1]
    alphas = [h.get("alpha", None) for h in bto_history]
    if all(a is not None for a in alphas):
        ax2.plot(iters, alphas, color="#9C27B0", lw=2.5)
        ax2.axhline(y=alphas[-1], color="gray", linestyle="--", alpha=0.5, label=f"α_final={alphas[-1]:.3f}")
        ax2.set_xlabel("Iteration", fontsize=12)
        ax2.set_ylabel("Exploitation Parameter α", fontsize=12)
        ax2.set_title("BTO α Decay Schedule (Cosine Annealing)", fontsize=13, fontweight="bold")
        ax2.legend(fontsize=10)
        ax2.grid(alpha=0.3)
    else:
        ax2.text(0.5, 0.5, "α values not available", ha="center", va="center",
                 transform=ax2.transAxes, fontsize=12)
        ax2.axis("off")

    plt.tight_layout()
    if save_path:
        plt.savefig(save_path, dpi=150, bbox_inches="tight")
    plt.show()


# ─────────────────────────────────────────────────────────────────────────────
# t-SNE Feature Visualization (Fig. 7)
# ─────────────────────────────────────────────────────────────────────────────

def plot_tsne(
    features: np.ndarray,
    labels: np.ndarray,
    class_names: Optional[List[str]] = None,
    title: str = "t-SNE Feature Space",
    perplexity: float = 30.0,
    n_iter: int = 1000,
    save_path: Optional[str] = None,
) -> None:
    """
    2D t-SNE visualization of fused feature embeddings.
    Reproduces Fig. 7 of the paper (separation of 4 classes).

    Args:
        features    : (N, D) numpy array of feature vectors
        labels      : (N,) integer class labels
        class_names : List of class label strings
        perplexity  : t-SNE perplexity
        n_iter      : t-SNE optimization iterations
        save_path   : Optional save path
    """
    if not (MPL_AVAILABLE and SKLEARN_AVAILABLE):
        print("matplotlib or scikit-learn not available.")
        return

    if class_names is None:
        class_names = LABEL_NAMES

    print("[t-SNE] Computing 2D embedding ...")
    tsne = TSNE(n_components=2, perplexity=perplexity, n_iter=n_iter,
                random_state=42, init="pca")
    emb = tsne.fit_transform(features)

    fig, ax = plt.subplots(figsize=(8, 7))

    for cls_idx, (cname, color) in enumerate(zip(class_names, CLASS_COLORS)):
        mask = labels == cls_idx
        ax.scatter(emb[mask, 0], emb[mask, 1],
                   c=color, label=cname, alpha=0.65, s=30, edgecolors="none")

    ax.set_title(title, fontsize=13, fontweight="bold")
    ax.set_xlabel("t-SNE Dimension 1", fontsize=11)
    ax.set_ylabel("t-SNE Dimension 2", fontsize=11)
    ax.legend(fontsize=11, loc="best")
    ax.grid(alpha=0.2)

    plt.tight_layout()
    if save_path:
        plt.savefig(save_path, dpi=150, bbox_inches="tight")
    plt.show()


# ─────────────────────────────────────────────────────────────────────────────
# Per-Class Metrics Bar Chart (Fig. 9)
# ─────────────────────────────────────────────────────────────────────────────

def plot_per_class_metrics(
    y_true: np.ndarray,
    y_pred: np.ndarray,
    class_names: Optional[List[str]] = None,
    save_path: Optional[str] = None,
) -> None:
    """
    Bar chart of per-class precision, recall, and F1-score.
    """
    if not MPL_AVAILABLE:
        return

    from sklearn.metrics import classification_report
    import pandas as pd

    if class_names is None:
        class_names = LABEL_NAMES[:len(np.unique(y_true))]

    report = classification_report(y_true, y_pred,
                                   target_names=class_names,
                                   output_dict=True, zero_division=0)

    metrics = ["precision", "recall", "f1-score"]
    x = np.arange(len(class_names))
    width = 0.25
    colors = ["#2196F3", "#4CAF50", "#FF9800"]

    fig, ax = plt.subplots(figsize=(10, 6))
    for i, (metric, color) in enumerate(zip(metrics, colors)):
        values = [report[cls][metric] for cls in class_names]
        bars = ax.bar(x + i * width, values, width, label=metric.capitalize(),
                      color=color, alpha=0.85, edgecolor="black", linewidth=0.5)
        for bar, val in zip(bars, values):
            ax.text(bar.get_x() + bar.get_width() / 2, bar.get_height() + 0.005,
                    f"{val:.3f}", ha="center", va="bottom", fontsize=8, rotation=45)

    ax.set_xlabel("Class", fontsize=12)
    ax.set_ylabel("Score", fontsize=12)
    ax.set_title("ERGT-BTO — Per-Class Precision / Recall / F1", fontsize=13, fontweight="bold")
    ax.set_xticks(x + width)
    ax.set_xticklabels(class_names, fontsize=11)
    ax.set_ylim(0, 1.12)
    ax.legend(fontsize=10)
    ax.grid(axis="y", alpha=0.3)

    plt.tight_layout()
    if save_path:
        plt.savefig(save_path, dpi=150, bbox_inches="tight")
    plt.show()


# ─────────────────────────────────────────────────────────────────────────────
# Comparative Performance Chart (Table 8)
# ─────────────────────────────────────────────────────────────────────────────

def plot_comparative_performance(
    results: Dict[str, Dict[str, float]],
    metric: str = "accuracy",
    save_path: Optional[str] = None,
) -> None:
    """
    Horizontal bar chart comparing ERGT-BTO against baseline methods.
    Reproduces Table 8 in visual form.

    Args:
        results : {method_name: {metric_name: value}}
        metric  : Which metric to plot
        save_path: Optional save path
    """
    if not MPL_AVAILABLE:
        return

    # Paper Table 8 baseline reference values (BACH dataset)
    DEFAULT_BASELINES = {
        "VGG-16 (Transfer)":         {"accuracy": 0.9125},
        "ResNet-50 (Transfer)":       {"accuracy": 0.9312},
        "InceptionV3 (Transfer)":     {"accuracy": 0.9438},
        "EfficientNet-B4":            {"accuracy": 0.9512},
        "ViT-B/16":                   {"accuracy": 0.9589},
        "GCN (Graph-only)":           {"accuracy": 0.9401},
        "RadiomicNet (CNN-only)":     {"accuracy": 0.9478},
        "ERGT-BTO (Proposed)":        {"accuracy": 0.9784},
    }

    data = results if results else DEFAULT_BASELINES
    methods = list(data.keys())
    values  = [data[m].get(metric, 0.0) for m in methods]

    # Color the proposed method differently
    colors = ["#4CAF50" if "ERGT-BTO" in m else "#90A4AE" for m in methods]

    fig, ax = plt.subplots(figsize=(10, max(5, len(methods) * 0.7)))
    bars = ax.barh(methods, values, color=colors, edgecolor="black", linewidth=0.5, height=0.6)

    for bar, val in zip(bars, values):
        ax.text(bar.get_width() + 0.002, bar.get_y() + bar.get_height() / 2,
                f"{val:.4f}", va="center", fontsize=10)

    ax.set_xlabel(metric.replace("_", " ").title(), fontsize=12)
    ax.set_title(f"ERGT-BTO vs Baselines — {metric.title()} (BACH Dataset)",
                 fontsize=13, fontweight="bold")
    ax.set_xlim(0.85, 1.02)
    ax.grid(axis="x", alpha=0.3)

    # Legend
    proposed_patch = mpatches.Patch(color="#4CAF50", label="ERGT-BTO (Proposed)")
    baseline_patch = mpatches.Patch(color="#90A4AE", label="Baseline Methods")
    ax.legend(handles=[proposed_patch, baseline_patch], fontsize=10, loc="lower right")

    plt.tight_layout()
    if save_path:
        plt.savefig(save_path, dpi=150, bbox_inches="tight")
    plt.show()


# ─────────────────────────────────────────────────────────────────────────────
# Training History Curves
# ─────────────────────────────────────────────────────────────────────────────

def plot_training_history(
    train_losses: List[float],
    val_losses: List[float],
    train_accs: List[float],
    val_accs: List[float],
    val_f1s: Optional[List[float]] = None,
    save_path: Optional[str] = None,
) -> None:
    """
    Plot training and validation loss + accuracy curves.

    Args:
        train_losses : Per-epoch training loss
        val_losses   : Per-epoch validation loss
        train_accs   : Per-epoch training accuracy
        val_accs     : Per-epoch validation accuracy
        val_f1s      : Per-epoch validation F1 (optional)
        save_path    : Optional save path
    """
    if not MPL_AVAILABLE:
        return

    epochs = range(1, len(train_losses) + 1)
    n_plots = 3 if val_f1s else 2
    fig, axes = plt.subplots(1, n_plots, figsize=(6 * n_plots, 5))

    # Loss
    axes[0].plot(epochs, train_losses, "b-o", ms=3, label="Train Loss")
    axes[0].plot(epochs, val_losses,   "r-o", ms=3, label="Val Loss")
    axes[0].set_title("Loss Curves", fontsize=12, fontweight="bold")
    axes[0].set_xlabel("Epoch"); axes[0].set_ylabel("Loss")
    axes[0].legend(); axes[0].grid(alpha=0.3)

    # Accuracy
    axes[1].plot(epochs, train_accs, "b-o", ms=3, label="Train Acc")
    axes[1].plot(epochs, val_accs,   "r-o", ms=3, label="Val Acc")
    axes[1].set_title("Accuracy Curves", fontsize=12, fontweight="bold")
    axes[1].set_xlabel("Epoch"); axes[1].set_ylabel("Accuracy")
    axes[1].legend(); axes[1].grid(alpha=0.3)
    axes[1].set_ylim(0, 1)

    # F1
    if val_f1s and n_plots == 3:
        axes[2].plot(epochs, val_f1s, "g-o", ms=3, label="Val F1")
        best_epoch = int(np.argmax(val_f1s)) + 1
        axes[2].axvline(x=best_epoch, color="red", linestyle="--",
                        alpha=0.7, label=f"Best epoch={best_epoch}")
        axes[2].set_title("Validation F1-Score", fontsize=12, fontweight="bold")
        axes[2].set_xlabel("Epoch"); axes[2].set_ylabel("Macro F1")
        axes[2].legend(); axes[2].grid(alpha=0.3)
        axes[2].set_ylim(0, 1)

    plt.suptitle("ERGT-BTO Training History", fontsize=14)
    plt.tight_layout()
    if save_path:
        plt.savefig(save_path, dpi=150, bbox_inches="tight")
    plt.show()


# ─────────────────────────────────────────────────────────────────────────────
# Attention Head Diversity Heatmap
# ─────────────────────────────────────────────────────────────────────────────

def plot_attention_head_diversity(
    attention_maps: List,
    layer_idx: int = -1,
    sample_idx: int = 0,
    save_path: Optional[str] = None,
) -> None:
    """
    Visualize attention weights per head for a single transformer layer.
    Helps illustrate multi-head diversity in tissue-scale reasoning.

    Args:
        attention_maps : List of (B, n_heads, seq, seq) tensors from model
        layer_idx      : Which transformer layer to visualize
        sample_idx     : Which sample in the batch to visualize
        save_path      : Optional save path
    """
    if not MPL_AVAILABLE:
        return

    import torch

    attn = attention_maps[layer_idx]     # (B, n_heads, seq, seq)
    attn_sample = attn[sample_idx].cpu().numpy()  # (n_heads, seq, seq)
    n_heads = attn_sample.shape[0]

    ncols = min(4, n_heads)
    nrows = (n_heads + ncols - 1) // ncols
    fig, axes = plt.subplots(nrows, ncols, figsize=(4 * ncols, 4 * nrows))
    axes = np.array(axes).flatten()

    for h in range(n_heads):
        ax = axes[h]
        im = ax.imshow(attn_sample[h], cmap="viridis", aspect="auto")
        ax.set_title(f"Head {h+1}", fontsize=10)
        ax.axis("off")
        plt.colorbar(im, ax=ax, fraction=0.046, pad=0.04)

    for h in range(n_heads, len(axes)):
        axes[h].axis("off")

    layer_label = f"Layer {layer_idx}" if layer_idx >= 0 else f"Layer {len(attention_maps)+layer_idx+1}"
    plt.suptitle(f"Transformer Attention Heads — {layer_label}", fontsize=13)
    plt.tight_layout()
    if save_path:
        plt.savefig(save_path, dpi=150, bbox_inches="tight")
    plt.show()
