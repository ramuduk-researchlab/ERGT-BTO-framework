"""
utils/metrics.py
================
Evaluation metrics for ERGT-BTO (Section 4.1–4.3).

Implements:
  - Accuracy, Precision, Recall, F1 (macro-averaged)
  - AUC (macro-averaged one-vs-rest)
  - Matthews Correlation Coefficient (MCC)
  - Cohen's Kappa
  - Balanced Accuracy (BACC)
  - Confusion matrix with visualization
"""

from __future__ import annotations

from typing import Dict, List, Optional, Tuple

import numpy as np
from sklearn.metrics import (
    accuracy_score,
    balanced_accuracy_score,
    cohen_kappa_score,
    confusion_matrix,
    f1_score,
    matthews_corrcoef,
    precision_score,
    recall_score,
    roc_auc_score,
)
from sklearn.preprocessing import label_binarize

try:
    import matplotlib.pyplot as plt
    import seaborn as sns
    VIZ_AVAILABLE = True
except ImportError:
    VIZ_AVAILABLE = False


LABEL_NAMES = ["Normal", "Benign", "In-Situ", "Invasive"]


def compute_all_metrics(
    y_true: np.ndarray,
    y_pred: np.ndarray,
    y_prob: Optional[np.ndarray] = None,
    class_names: Optional[List[str]] = None,
    num_classes: int = 4,
) -> Dict[str, float]:
    """
    Compute the full evaluation metric suite used in the paper.

    Args:
        y_true      : (N,) integer ground-truth labels
        y_pred      : (N,) integer predicted labels
        y_prob      : (N, C) class probability matrix (needed for AUC)
        class_names : Optional label names for display
        num_classes : Number of output classes

    Returns:
        metrics: Dict with keys: accuracy, precision, recall, f1, auc, mcc,
                                 kappa, balanced_accuracy
    """
    if class_names is None:
        class_names = LABEL_NAMES[:num_classes]

    metrics: Dict[str, float] = {}

    metrics["accuracy"]          = accuracy_score(y_true, y_pred)
    metrics["balanced_accuracy"] = balanced_accuracy_score(y_true, y_pred)
    metrics["precision"]         = precision_score(y_true, y_pred, average="macro", zero_division=0)
    metrics["recall"]            = recall_score(y_true, y_pred, average="macro", zero_division=0)
    metrics["f1"]                = f1_score(y_true, y_pred, average="macro", zero_division=0)
    metrics["mcc"]               = matthews_corrcoef(y_true, y_pred)
    metrics["kappa"]             = cohen_kappa_score(y_true, y_pred)

    if y_prob is not None:
        y_bin = label_binarize(y_true, classes=list(range(num_classes)))
        try:
            metrics["auc"] = roc_auc_score(y_bin, y_prob, average="macro", multi_class="ovr")
        except ValueError:
            metrics["auc"] = float("nan")
    else:
        metrics["auc"] = float("nan")

    return metrics


def print_metrics(metrics: Dict[str, float], title: str = "Evaluation Metrics") -> None:
    """Pretty-print the evaluation metric dictionary."""
    print(f"\n{'─'*45}")
    print(f"  {title}")
    print(f"{'─'*45}")
    order = ["accuracy", "balanced_accuracy", "precision", "recall",
             "f1", "auc", "mcc", "kappa"]
    labels = {
        "accuracy":          "Accuracy",
        "balanced_accuracy": "Balanced Acc (BACC)",
        "precision":         "Precision (macro)",
        "recall":            "Recall (macro)",
        "f1":                "F1-Score (macro)",
        "auc":               "AUC (macro OvR)",
        "mcc":               "MCC",
        "kappa":             "Cohen's Kappa",
    }
    for key in order:
        val = metrics.get(key, float("nan"))
        print(f"  {labels.get(key, key):<25}: {val:.4f}")
    print(f"{'─'*45}\n")


def plot_confusion_matrix(
    y_true: np.ndarray,
    y_pred: np.ndarray,
    class_names: Optional[List[str]] = None,
    save_path: Optional[str] = None,
    title: str = "Confusion Matrix",
    normalize: bool = True,
) -> None:
    """
    Plot a normalized confusion matrix.

    Args:
        y_true      : Ground-truth labels
        y_pred      : Predicted labels
        class_names : Label strings for axes
        save_path   : Save figure to this path
        title       : Figure title
        normalize   : Show percentages if True, counts if False
    """
    if not VIZ_AVAILABLE:
        print("matplotlib/seaborn not available.")
        return

    cm = confusion_matrix(y_true, y_pred)
    if normalize:
        cm_plot = cm.astype(float) / (cm.sum(axis=1, keepdims=True) + 1e-8)
        fmt = ".2%"
    else:
        cm_plot = cm
        fmt = "d"

    if class_names is None:
        class_names = LABEL_NAMES[:cm.shape[0]]

    fig, ax = plt.subplots(figsize=(7, 6))
    sns.heatmap(
        cm_plot, annot=True, fmt=fmt, cmap="Blues",
        xticklabels=class_names, yticklabels=class_names,
        ax=ax, linewidths=0.5,
    )
    ax.set_xlabel("Predicted Label", fontsize=12)
    ax.set_ylabel("True Label", fontsize=12)
    ax.set_title(title, fontsize=13, fontweight="bold")
    plt.tight_layout()

    if save_path:
        plt.savefig(save_path, dpi=150, bbox_inches="tight")
    plt.show()


def plot_roc_curves(
    y_true: np.ndarray,
    y_prob: np.ndarray,
    class_names: Optional[List[str]] = None,
    save_path: Optional[str] = None,
) -> None:
    """
    Plot per-class ROC curves (Fig. 8 equivalent in the paper).
    """
    if not VIZ_AVAILABLE:
        return

    from sklearn.metrics import roc_curve, auc

    num_classes = y_prob.shape[1]
    if class_names is None:
        class_names = LABEL_NAMES[:num_classes]

    y_bin = label_binarize(y_true, classes=list(range(num_classes)))
    colors = ["#2196F3", "#4CAF50", "#FF9800", "#F44336"]

    fig, ax = plt.subplots(figsize=(7, 6))
    for i, (cname, color) in enumerate(zip(class_names, colors)):
        fpr, tpr, _ = roc_curve(y_bin[:, i], y_prob[:, i])
        auc_score = auc(fpr, tpr)
        ax.plot(fpr, tpr, color=color, lw=2, label=f"{cname} (AUC = {auc_score:.3f})")

    ax.plot([0, 1], [0, 1], "k--", lw=1, label="Random")
    ax.set_xlabel("False Positive Rate", fontsize=12)
    ax.set_ylabel("True Positive Rate", fontsize=12)
    ax.set_title("ROC Curves – ERGT-BTO", fontsize=13, fontweight="bold")
    ax.legend(loc="lower right", fontsize=10)
    ax.grid(alpha=0.3)
    plt.tight_layout()

    if save_path:
        plt.savefig(save_path, dpi=150, bbox_inches="tight")
    plt.show()
