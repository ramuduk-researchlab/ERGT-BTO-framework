"""
explainability/attention_rollout.py
=====================================
Transformer Attention Rollout Visualization (Section 3.3.5, Section 4.3).

Implements the Abnar & Zuidema (2020) attention rollout method to
propagate attention through all transformer layers and compute a
spatial importance map over the input image patches.

Reference:
    Abnar, S. & Zuidema, W. Quantifying attention flow in transformers.
    ACL 2020. https://doi.org/10.18653/v1/2020.acl-main.385
"""

from __future__ import annotations

from typing import List, Optional, Tuple

import numpy as np
import torch
import torch.nn.functional as F

try:
    import matplotlib.pyplot as plt
    import matplotlib.cm as cm
    MPL_AVAILABLE = True
except ImportError:
    MPL_AVAILABLE = False


# ─────────────────────────────────────────────────────────────────────────────
# Attention rollout computation
# ─────────────────────────────────────────────────────────────────────────────

def compute_attention_rollout(
    attention_maps: List[torch.Tensor],
    head_fusion: str = "mean",
    discard_ratio: float = 0.9,
) -> torch.Tensor:
    """
    Compute attention rollout across transformer layers (Abnar & Zuidema 2020).

    Algorithm:
      For each layer l:
        1. Average (or max) attention across heads: A_l (B, seq, seq)
        2. Add residual: Â_l = 0.5 * A_l + 0.5 * I
        3. Normalize rows to sum to 1
      Roll out: R = Â_L × Â_{L-1} × ... × Â_1

    The [CLS] row of R gives the relative attention each patch received
    from the final representation.

    Args:
        attention_maps : List of (B, n_heads, seq, seq) attention weight tensors
        head_fusion    : How to combine heads – 'mean' | 'max' | 'min'
        discard_ratio  : Fraction of lowest attentions to zero out (noise removal)

    Returns:
        rollout: (B, seq) attention rollout for [CLS] token → all patches
    """
    B, _, seq_len, _ = attention_maps[0].shape
    rollout = torch.eye(seq_len, device=attention_maps[0].device).unsqueeze(0).repeat(B, 1, 1)

    for attn in attention_maps:
        # Head fusion
        if head_fusion == "mean":
            attn_fused = attn.mean(dim=1)        # (B, seq, seq)
        elif head_fusion == "max":
            attn_fused = attn.max(dim=1).values
        elif head_fusion == "min":
            attn_fused = attn.min(dim=1).values
        else:
            raise ValueError(f"Unknown head_fusion: {head_fusion}")

        # Discard lowest attention values (noise suppression)
        flat = attn_fused.view(B, -1)
        threshold = torch.quantile(flat, discard_ratio, dim=1, keepdim=True).view(B, 1, 1)
        attn_fused = torch.where(attn_fused >= threshold,
                                 attn_fused,
                                 torch.zeros_like(attn_fused))

        # Residual connection: Â = 0.5·A + 0.5·I
        identity = torch.eye(seq_len, device=attn.device).unsqueeze(0).repeat(B, 1, 1)
        attn_res = 0.5 * attn_fused + 0.5 * identity

        # Row normalization
        row_sum = attn_res.sum(dim=-1, keepdim=True).clamp(min=1e-8)
        attn_norm = attn_res / row_sum

        # Accumulate rollout
        rollout = torch.bmm(attn_norm, rollout)

    # Return [CLS] row (index 0) – attention from CLS to all patches
    cls_rollout = rollout[:, 0, 1:]   # (B, n_patches) — skip CLS itself
    return cls_rollout


# ─────────────────────────────────────────────────────────────────────────────
# Spatial attention map overlay
# ─────────────────────────────────────────────────────────────────────────────

def rollout_to_heatmap(
    rollout: torch.Tensor,
    grid_h: int,
    grid_w: int,
    img_h: int = 224,
    img_w: int = 224,
) -> np.ndarray:
    """
    Reshape rollout vector to spatial heatmap and upsample to image size.

    Args:
        rollout : (n_patches,) or (1, n_patches) rollout for one image
        grid_h  : Number of patch rows
        grid_w  : Number of patch columns
        img_h   : Target heatmap height
        img_w   : Target heatmap width

    Returns:
        heatmap : (img_h, img_w) numpy float32 in [0, 1]
    """
    r = rollout.squeeze()
    r = r.cpu().float()
    r = r.reshape(1, 1, grid_h, grid_w)
    heatmap = F.interpolate(r, size=(img_h, img_w), mode="bilinear", align_corners=False)
    heatmap = heatmap.squeeze().numpy()
    # Normalize to [0, 1]
    heatmap = (heatmap - heatmap.min()) / (heatmap.max() - heatmap.min() + 1e-8)
    return heatmap.astype(np.float32)


# ─────────────────────────────────────────────────────────────────────────────
# Visualization
# ─────────────────────────────────────────────────────────────────────────────

def visualize_attention_rollout(
    image: torch.Tensor,
    rollout: torch.Tensor,
    grid_h: int,
    grid_w: int,
    class_name: str = "",
    alpha: float = 0.5,
    colormap: str = "jet",
    save_path: Optional[str] = None,
    ax=None,
) -> None:
    """
    Overlay attention rollout heatmap on the original image.

    Args:
        image     : (3, H, W) or (1, 3, H, W) tensor in [0,1] or normalized range
        rollout   : (n_patches,) attention rollout for this image
        grid_h/w  : Patch grid dimensions
        class_name: Predicted class label for plot title
        alpha     : Heatmap overlay transparency
        colormap  : Matplotlib colormap name
        save_path : Save figure to this path if provided
        ax        : Optional existing matplotlib Axes
    """
    if not MPL_AVAILABLE:
        print("matplotlib not available; skipping visualization.")
        return

    img = image.squeeze(0).cpu().float()
    H, W = img.shape[-2], img.shape[-1]

    # Denormalize image for display
    img_np = img.numpy().transpose(1, 2, 0)
    img_np = (img_np - img_np.min()) / (img_np.max() - img_np.min() + 1e-8)
    img_np = img_np.clip(0, 1)

    heatmap = rollout_to_heatmap(rollout, grid_h, grid_w, H, W)

    show_alone = ax is None
    if show_alone:
        fig, axes = plt.subplots(1, 3, figsize=(12, 4))
    else:
        axes = [None, None, ax]

    if show_alone:
        axes[0].imshow(img_np)
        axes[0].set_title("Original Image")
        axes[0].axis("off")

        axes[1].imshow(heatmap, cmap=colormap)
        axes[1].set_title("Attention Rollout")
        axes[1].axis("off")

    target_ax = axes[2] if show_alone else ax
    target_ax.imshow(img_np)
    target_ax.imshow(heatmap, cmap=colormap, alpha=alpha)
    target_ax.set_title(f"Overlay – {class_name}")
    target_ax.axis("off")

    if show_alone:
        plt.suptitle("ERGT-BTO Transformer Attention Rollout", fontsize=13)
        plt.tight_layout()
        if save_path:
            plt.savefig(save_path, dpi=150, bbox_inches="tight")
        plt.show()


# ─────────────────────────────────────────────────────────────────────────────
# High-level helper
# ─────────────────────────────────────────────────────────────────────────────

class AttentionRolloutVisualizer:
    """
    Convenience class for attention rollout on batches of images.

    Usage:
        viz = AttentionRolloutVisualizer(model, patch_size=16, img_size=224)
        viz.visualize_batch(images, labels, class_names, save_dir="./plots")
    """

    def __init__(
        self,
        model,
        patch_size: int = 16,
        img_size: int = 224,
        head_fusion: str = "mean",
        discard_ratio: float = 0.9,
        device: str = "cuda",
    ):
        self.model = model
        self.patch_size = patch_size
        self.grid_h = img_size // patch_size
        self.grid_w = img_size // patch_size
        self.head_fusion = head_fusion
        self.discard_ratio = discard_ratio
        self.device = device

    def get_rollout(self, images: torch.Tensor) -> torch.Tensor:
        """
        Run a forward pass and compute attention rollout.

        Args:
            images: (B, 3, H, W)
        Returns:
            rollout: (B, n_patches)
        """
        self.model.eval()
        with torch.no_grad():
            _ = self.model(images.to(self.device))
        attn_maps = self.model.get_attention_maps()
        rollout = compute_attention_rollout(attn_maps, self.head_fusion, self.discard_ratio)
        return rollout

    def visualize_batch(
        self,
        images: torch.Tensor,
        labels: List[int],
        class_names: List[str],
        save_dir: Optional[str] = None,
        max_images: int = 8,
    ) -> None:
        if not MPL_AVAILABLE:
            return

        rollout = self.get_rollout(images)
        n = min(len(images), max_images)

        fig, axes = plt.subplots(n, 3, figsize=(12, 4 * n))
        if n == 1:
            axes = [axes]

        for i in range(n):
            img = images[i].cpu().float()
            img_np = img.numpy().transpose(1, 2, 0)
            img_np = (img_np - img_np.min()) / (img_np.max() - img_np.min() + 1e-8)
            heatmap = rollout_to_heatmap(
                rollout[i], self.grid_h, self.grid_w,
                img_np.shape[0], img_np.shape[1]
            )
            cls_name = class_names[labels[i]] if labels[i] < len(class_names) else str(labels[i])

            axes[i][0].imshow(img_np); axes[i][0].set_title("Image"); axes[i][0].axis("off")
            axes[i][1].imshow(heatmap, cmap="jet"); axes[i][1].set_title("Rollout"); axes[i][1].axis("off")
            axes[i][2].imshow(img_np)
            axes[i][2].imshow(heatmap, cmap="jet", alpha=0.5)
            axes[i][2].set_title(f"Overlay – {cls_name}"); axes[i][2].axis("off")

        plt.tight_layout()
        if save_dir:
            import os
            os.makedirs(save_dir, exist_ok=True)
            plt.savefig(f"{save_dir}/attention_rollout.png", dpi=150, bbox_inches="tight")
        plt.show()
