"""
explainability/shap_explainer.py
=================================
SHAP-based feature attribution for ERGT-BTO (Section 3.3.5, Section 4.3).

Provides:
  1. Feature-level SHAP values for radiomic + GCN + transformer features
  2. Bar plots of mean absolute SHAP values per feature group
  3. Beeswarm summary plots

Key findings from the paper (Section 5):
  - GLCM entropy (tissue heterogeneity): most influential feature
  - GCN graph degree (cellular density): second most influential
  - Transformer attention weights: third most influential
"""

from __future__ import annotations

from typing import Dict, List, Optional, Tuple

import numpy as np
import torch
import torch.nn as nn

try:
    import shap
    SHAP_AVAILABLE = True
except ImportError:
    SHAP_AVAILABLE = False
    print("[Warning] shap not installed. Run: pip install shap")

try:
    import matplotlib.pyplot as plt
    import matplotlib.colors as mcolors
    MPL_AVAILABLE = True
except ImportError:
    MPL_AVAILABLE = False


# ─────────────────────────────────────────────────────────────────────────────
# Feature-level SHAP explanation
# ─────────────────────────────────────────────────────────────────────────────

class ERGTSHAPExplainer:
    """
    SHAP explainer for the ERGT-BTO classifier head.

    Uses SHAP DeepExplainer on the fused feature representation
    (radiomic + GCN + transformer), explaining the classifier's
    per-class output.

    Usage:
        explainer = ERGTSHAPExplainer(model, background_loader)
        shap_vals = explainer.compute_shap_values(test_images)
        explainer.plot_summary(shap_vals, feature_names)
    """

    def __init__(
        self,
        model: nn.Module,
        background_images: torch.Tensor,
        device: str = "cuda",
        n_background: int = 50,
    ):
        if not SHAP_AVAILABLE:
            raise ImportError("Install shap: pip install shap")

        self.model = model.eval()
        self.device = device
        self.n_background = n_background

        # Sub-sample background set
        idx = torch.randperm(background_images.size(0))[:n_background]
        self.background = background_images[idx].to(device)

        # Wrap model to output fused features for SHAP
        self._feature_wrapper = self._build_feature_wrapper()
        self.explainer = shap.DeepExplainer(self._feature_wrapper, self.background)

    def _build_feature_wrapper(self):
        """
        Wrap the model to return classifier logits directly.
        SHAP will explain these logits w.r.t. image input.
        """
        model = self.model

        class _Wrapper(nn.Module):
            def forward(self, x):
                with torch.no_grad():
                    logits = model(x)
                return logits

        return _Wrapper().to(self.device)

    def compute_shap_values(
        self,
        images: torch.Tensor,
    ) -> List[np.ndarray]:
        """
        Compute SHAP values for a batch of images.

        Args:
            images: (B, C, H, W) tensor

        Returns:
            shap_values: List of arrays, one per class, each (B, C, H, W)
        """
        images = images.to(self.device)
        shap_values = self.explainer.shap_values(images)
        return shap_values

    def get_feature_importance(
        self,
        shap_values: List[np.ndarray],
        class_idx: Optional[int] = None,
    ) -> np.ndarray:
        """
        Aggregate pixel-level SHAP values to per-channel mean |SHAP|.

        Args:
            shap_values : Output of compute_shap_values()
            class_idx   : Class to explain; if None, averages across classes

        Returns:
            importance: (C,) mean absolute SHAP per channel
        """
        if class_idx is not None:
            sv = shap_values[class_idx]  # (B, C, H, W)
        else:
            sv = np.mean(np.abs(np.stack(shap_values, axis=0)), axis=0)  # (B, C, H, W)

        return np.abs(sv).mean(axis=(0, 2, 3))  # (C,)

    def plot_summary(
        self,
        shap_values: List[np.ndarray],
        images: torch.Tensor,
        class_names: List[str] = None,
        save_path: Optional[str] = None,
    ) -> None:
        """
        Plot per-class mean |SHAP| bar charts.

        Args:
            shap_values : List of per-class SHAP arrays
            images      : Test images (used as display samples)
            class_names : Optional class label strings
            save_path   : Path to save the figure
        """
        if not MPL_AVAILABLE:
            print("matplotlib not available; skipping SHAP plot.")
            return

        if class_names is None:
            class_names = [f"Class {i}" for i in range(len(shap_values))]

        n_classes = len(shap_values)
        fig, axes = plt.subplots(1, n_classes, figsize=(5 * n_classes, 5))
        if n_classes == 1:
            axes = [axes]

        colors = ["#2196F3", "#4CAF50", "#FF9800", "#F44336"]

        for cls_i, (sv, cname) in enumerate(zip(shap_values, class_names)):
            mean_shap = np.abs(sv).mean(axis=(0, 2, 3))  # (C,)
            chan_labels = [f"R", f"G", f"B"][:len(mean_shap)]

            ax = axes[cls_i]
            bars = ax.bar(chan_labels, mean_shap,
                          color=colors[cls_i % len(colors)], alpha=0.8, edgecolor="black")
            ax.set_title(f"SHAP – {cname}", fontsize=12, fontweight="bold")
            ax.set_xlabel("Channel")
            ax.set_ylabel("Mean |SHAP|")

            # Value annotations
            for bar, val in zip(bars, mean_shap):
                ax.text(bar.get_x() + bar.get_width() / 2, bar.get_height() * 1.02,
                        f"{val:.4f}", ha="center", va="bottom", fontsize=9)

        plt.suptitle("SHAP Feature Importance by Class (ERGT-BTO)", fontsize=14)
        plt.tight_layout()
        if save_path:
            plt.savefig(save_path, dpi=150, bbox_inches="tight")
        plt.show()


# ─────────────────────────────────────────────────────────────────────────────
# Gradient-based saliency (fallback if SHAP unavailable)
# ─────────────────────────────────────────────────────────────────────────────

class GradientSaliency:
    """
    Gradient × Input saliency as a SHAP-like approximation.
    Used as a fallback when the SHAP library is not installed.
    """

    def __init__(self, model: nn.Module, device: str = "cuda"):
        self.model = model
        self.device = device

    def compute(self, image: torch.Tensor, class_idx: int) -> np.ndarray:
        """
        Compute gradient × input saliency map.

        Args:
            image     : (1, C, H, W) single image tensor
            class_idx : Target class index

        Returns:
            saliency: (H, W) aggregated saliency map
        """
        self.model.eval()
        img = image.to(self.device).requires_grad_(True)
        logits = self.model(img)
        score = logits[0, class_idx]
        score.backward()

        saliency = img.grad.data.abs().squeeze(0)   # (C, H, W)
        saliency = saliency.mean(dim=0)              # (H, W)
        saliency = saliency.cpu().numpy()
        saliency = (saliency - saliency.min()) / (saliency.max() - saliency.min() + 1e-8)
        return saliency
